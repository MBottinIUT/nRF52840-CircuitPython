"""CLUE 8.4.8 : éclairage caméléon"""
# importation des modules natifs utiles
from time import *
from board import *
from displayio import *
# importation de modules supplémentaires
from adafruit_clue import clue
from adafruit_progressbar import ProgressBar
from adafruit_tcs34725 import TCS34725
from simpleio import map_range
from neopixel import *

# Instanciation du capteur de couleurs
capteur_couleur = TCS34725(clue._i2c)

# Instanciation de l'écran
ecran = DISPLAY

# Mise en place et affichage du groupe principal (5 objets max)
groupe_principal = Group(max_size=5)
ecran.show(groupe_principal)

# Mise en place du fond de couleur
color_bitmap = Bitmap(240, 240, 1)
color_palette = Palette(1)
color_palette[0] = 0x000000
fond = TileGrid(color_bitmap,pixel_shader=color_palette,x=0, y=0)
groupe_principal.append(fond)

# Instanciation des barres de progression pour chaque composante de couleur
barre_rouge = ProgressBar(20, 40, 200, 30, 0.0, stroke=1, bar_color = clue.RED)
groupe_principal.append(barre_rouge)
barre_verte = ProgressBar(20, 110, 200, 30, 0.0, stroke=1, bar_color = clue.GREEN)
groupe_principal.append(barre_verte)
barre_bleue = ProgressBar(20, 180, 200, 30, 0.0, stroke=1, bar_color = clue.BLUE)
groupe_principal.append(barre_bleue)

# Instanciation du ruban Neopixel à 10 LED
led = NeoPixel(D8, 64, brightness=1.0)

val_max = 60

# ---------------------------------------
# -------  BOUCLE PRINCIPALE  -----------
# ---------------------------------------
while True:
    # Récupération des trois composantes de couleur depuis le capteur TCS34725
    comp_rouge, comp_vert, comp_bleu = capteur_couleur.color_rgb_bytes
    #print ("R: {} / V: {} / B: {}".format(comp_rouge,comp_vert,comp_bleu))
    # Conditionnement des trois composantes pour qu'elles soient dans la plage 0-255
    comp_rouge = int(map_range(comp_rouge,0,val_max,0,255))
    comp_vert = int(map_range(comp_vert,0,val_max,0,255))
    comp_bleu = int(map_range(comp_bleu,0,val_max,0,255))
    # Changement de la couleur du fond conformément à la couleur détectée
    color_palette[0] = (comp_rouge,comp_vert,comp_bleu)
    # Mise à jour des barres de progression pour chaque couleur
    barre_rouge.progress = comp_rouge/255
    barre_verte.progress = comp_vert/255
    barre_bleue.progress = comp_bleu/255
    # Mise à jour de l'éclairage Neopixel
    for i in range (led.n) :
        led[i] = (comp_rouge,comp_vert,comp_bleu)
    # Pause
    sleep(0.25)
