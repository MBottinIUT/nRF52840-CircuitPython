"""CLUE 8.4.3 : thermometre"""
# importation des modules natifs utiles
from board import *
from time import *
from displayio import *
# importation de modules supplémentaires
from adafruit_clue import clue
from adafruit_display_text import label
from adafruit_bitmap_font import bitmap_font
from adafruit_display_shapes.rect import Rect

# Instanciation de l'écran
ecran = DISPLAY

# Mise en place et affichage du groupe principal (3 objets max)
groupe_principal = Group(max_size=3)
ecran.show(groupe_principal)

# Mise en place de l'image de fond dans le groupe_principal
fichier = open("/images/Fond_thermometre.bmp", "rb")
page = OnDiskBitmap(fichier)
tuile_image = TileGrid(page, pixel_shader=ColorConverter(),x=0,y=0)
groupe_principal.append(tuile_image)

# Chargement de la police bdf
police = bitmap_font.load_font("/fonts/SweetWinter35.bdf")

# Création d'un groupe 'temperature' avec un label
groupe_temperature = Group(max_size=1,scale=1)
texte_temperature = label.Label(police, text="__°C", max_glyphs=5, color=clue.WHITE, x=100, y=110)
groupe_temperature.append(texte_temperature)
groupe_principal.append(groupe_temperature)

# Création de la barre de température
couleur_barre = 0xFF110B
barre_temperature = Rect(49, 38, 2, 150, fill=couleur_barre)
groupe_principal.append(barre_temperature)

# ---------------------------------------
# -------  BOUCLE PRINCIPALE  -----------
# ---------------------------------------
while True:
    # Lecture de la température de la carte CLUE
    temperature = int(clue.temperature)
    # Mise à jour du label affichant la température
    texte_temperature.text = str(temperature) + "°C"
    # Calcul des coordonnées et dimensions de la colonne du thermomètre
    y_barre = int((-1.667*temperature)+121.33)
    hauteur_barre = 188 - y_barre
    # Mise à jour de la colonne du thermomètre
    barre_temperature.y = y_barre
    barre_temperature.height = hauteur_barre
    # Pause de 1 seconde
    sleep(1)



