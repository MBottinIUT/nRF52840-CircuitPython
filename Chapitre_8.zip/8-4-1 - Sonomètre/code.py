"""CLUE 8.4.1 : sonomètre"""
# importation des modules natifs utiles
from board import *
from terminalio import *
from displayio import *
# importation de modules supplémentaires
from adafruit_clue import clue
from adafruit_progressbar import ProgressBar
from adafruit_display_text import label
from simpleio import map_range

# Instanciation de l'écran
ecran = DISPLAY

# Mise en place et affichage du groupe principal (3 objets max)
groupe_principal = Group(max_size=3)
ecran.show(groupe_principal)

# Mise en place de l'image de fond dans le groupe_principal
fichier = open("/images/fond_decibelmetre.bmp", "rb")
page = OnDiskBitmap(fichier)
tuile_image = TileGrid(page, pixel_shader=ColorConverter(),x=0,y=0)
groupe_principal.append(tuile_image)

# Création d'un groupe 'niveau' avec un label
groupe_niveau = Group(max_size=1,scale=2)
texte_niveau = label.Label(FONT, text="...%", max_glyphs=5, color=clue.VIOLET, x=50, y=100)
groupe_niveau.append(texte_niveau)
groupe_principal.append(groupe_niveau)

# Instanciation d'une barre de progression dans le groupe_principal
barre_niveau_sonore = ProgressBar(19, 150, 201, 30, 0.0, stroke=1, bar_color = clue.VIOLET)
groupe_principal.append(barre_niveau_sonore)

# config niveau max
niveau_max = 1000

# ---------------------------------------
# -------  BOUCLE PRINCIPALE  -----------
# ---------------------------------------
while True:
    # Récupération du niveau sonore ambiant
    niveau_sonore = clue.sound_level
    # Limitation du niveau sonore à la valeur 'niveau_max'
    if niveau_sonore > niveau_max :
        niveau_sonore = niveau_max
    # conversion du niveau sonore [0;niveau_max] --> [0,1.0]
    niveau_sonore_converti = map_range(niveau_sonore, 0, niveau_max, 0, 1.0)
    # Mise à jour de l'affichage du label
    texte_niveau.text = str(int(niveau_sonore_converti*100)) + "%"
    # Mise à jour de la barre de progression
    barre_niveau_sonore.progress = niveau_sonore_converti


