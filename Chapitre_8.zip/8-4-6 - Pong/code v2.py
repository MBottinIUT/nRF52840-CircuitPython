"""CLUE 8.4.4 : pong v2"""
# importation des modules natifs utiles
from board import *
from time import *
from terminalio import *
from displayio import *
from random import *
from analogio import *
# importation de modules supplémentaires
from adafruit_clue import clue
from adafruit_display_shapes.circle import Circle
from adafruit_display_shapes.roundrect import RoundRect
from adafruit_display_text import label
from simpleio import map_range

# Instanciation de l'écran
ecran = DISPLAY

# Mise en place et affichage du groupe principal (3 objets max)
groupe_principal = Group(max_size=4)
ecran.show(groupe_principal)

# Mise en place de l'image de fond dans le groupe_principal
fichier = open("/images/fond_pong.bmp", "rb")
page = OnDiskBitmap(fichier)
tuile_image = TileGrid(page, pixel_shader=ColorConverter(),x=0,y=0)
groupe_principal.append(tuile_image)

# Création d'un label pour le score
texte_score = label.Label(FONT, text="Score:00", max_glyphs=10, color=clue.VIOLET, x=175, y=10)
groupe_principal.append(texte_score)

# variables
x_balle = randint(10,230)
y_balle = randint(10,100)
rayon_balle = 6
x_raquette = 20
y_raquette = 220
largeur_raquette = 50
delta_balle_x = 1
delta_balle_y = 1
delta_raquette = +1
score=0

# Ajout de la balle et de la raquette au groupe principal
balle = Circle(x_balle, y_balle, rayon_balle, fill=clue.WHITE, outline=clue.VIOLET)
groupe_principal.append(balle)
raquette = RoundRect(x_raquette, y_raquette, largeur_raquette, 15, 10, fill=clue.WHITE, outline=clue.VIOLET, stroke=3)
groupe_principal.append(raquette)

# Instanciation d'une broche analogique
telemetre = AnalogIn(A2)

# Fonction de calcul de la tension sur la broche analogique
def mesure_tension(broche) :
    return (broche.value *3.3)/65536

# Fonction de détermination de la distance de l'obstacle
def calcul_distance(tension) :
    return ((13 - (0.42*tension))/tension)

# ---------------------------------------
# -------  BOUCLE PRINCIPALE  -----------
# ---------------------------------------
while True:
    # Déplacement de la balle
    x_balle = x_balle + delta_balle_x
    y_balle = y_balle + delta_balle_y
    balle.x = x_balle
    balle.y = y_balle
    # Les différents tests liés à la balle
    # Est-ce que la balle a atteint le bord droit de l'écran ?
    if (x_balle == 239 - rayon_balle) :
        delta_balle_x = -1
    # Est-ce que la balle a atteint le bord gauche de l'écran ?
    if (x_balle == 0 + rayon_balle) :
        delta_balle_x = 1
    # Est-ce que la balle a été reçue sur la raquette ?
    if (y_balle+ rayon_balle == y_raquette) and (x_raquette <= x_balle <= x_raquette+largeur_raquette) :
        # Elle rebondit
        delta_balle_y = -1
        clue.play_tone(880, 0.1)
        # Le score augmente d'une unité
        score = score +1
        texte_score.text = "Score:{}".format(score)
    # ou est-ce que la raquette a loupé la balle ?
    elif (y_balle+ rayon_balle > y_raquette) and ((x_balle <= x_raquette) or (x_balle >= x_raquette+largeur_raquette)) :
        # Le score diminue d'une unité
        score =  score -1
        texte_score.text = "Score:{}".format(score)
        clue.play_tone(650, 0.1)
        # La balle est repositionnée de manière aléatoire
        x_balle = randint(10,230)
        y_balle = randint(10,100)
    # Est-ce que la balle a atteint le haut de l'écran
    elif (y_balle == 0 + rayon_balle) :
        delta_balle_y = 1
    # On récupère la distance du capteur
    distance_main = 10*round(calcul_distance(mesure_tension(telemetre)),1)
    #print('Range: {}mm'.format(distance_main))
    if (distance_main < 200) :
        # Si la distance est <200mm, on positionne la raquette proportionnellement à cette distance
        x_raquette = map_range(distance_main,30,200,0,239-largeur_raquette)
    # Déplacement de la raquette
    raquette.x = int(x_raquette)
    sleep(0.005)
