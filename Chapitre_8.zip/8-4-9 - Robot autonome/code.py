""" CLUE 8.4.10 : robot autonome"""
# Importation des modules natifs utiles
from time import *
from board import *
from digitalio import *
from random import *
from displayio import *
# importation de modules supplémentaires
from adafruit_clue import clue
from adafruit_display_shapes.circle import Circle
import adafruit_vl6180x

# Instanciation de l'écran
ecran = DISPLAY

# Mise en place et affichage du groupe principal (3 objets max)
groupe_principal = Group(max_size=3)
ecran.show(groupe_principal)

# Mise en place de l'image de fond dans le groupe_principal
fichier = open("/images/Visage_robot.bmp", "rb")
page = OnDiskBitmap(fichier)
tuile_image = TileGrid(page, pixel_shader=ColorConverter(),x=0,y=0)
groupe_principal.append(tuile_image)

# Création d'un groupe 'oeil_gauche'
groupe_oeil_gauche = Group(max_size=3)
iris_gauche = Circle(65, 123, 21, fill=clue.AQUA, outline=clue.BLACK)
pupille_gauche = Circle(65, 123, 13, fill=clue.BLACK, outline=clue.BLACK)
reflet_gauche = Circle(70, 118, 3, fill=clue.WHITE, outline=clue.WHITE)
groupe_oeil_gauche.append(iris_gauche)
groupe_oeil_gauche.append(pupille_gauche)
groupe_oeil_gauche.append(reflet_gauche)
groupe_principal.append(groupe_oeil_gauche)

# Création d'un groupe 'oeil_droit'
groupe_oeil_droit = Group(max_size=3)
iris_droit = Circle(174, 123, 21, fill=clue.AQUA, outline=clue.BLACK)
pupille_droit = Circle(174, 123, 13, fill=clue.BLACK, outline=clue.BLACK)
reflet_droit = Circle(174, 118, 3, fill=clue.WHITE, outline=clue.WHITE)
groupe_oeil_droit.append(iris_droit)
groupe_oeil_droit.append(pupille_droit)
groupe_oeil_droit.append(reflet_droit)
groupe_principal.append(groupe_oeil_droit)

# Configuration des broches pour piloter les moteurs droit et gauche
moteur_gauche_1 = DigitalInOut(P16)
moteur_gauche_1.direction = Direction.OUTPUT
moteur_gauche_2 = DigitalInOut(P8)
moteur_gauche_2.direction = Direction.OUTPUT
moteur_droit_1 = DigitalInOut(P14)
moteur_droit_1.direction = Direction.OUTPUT
moteur_droit_2 = DigitalInOut(P12)
moteur_droit_2.direction = Direction.OUTPUT

# Fonction pour faire avancer le robot à pleine vitesse
def robot_tout_droit() :
    moteur_gauche_1.value = True
    moteur_droit_1.value = True
    moteur_gauche_2.value = False
    moteur_droit_2.value = False

# Fonction pour faire tourner le robot vers la gauche
def robot_gauche() :
    moteur_gauche_1.value = False
    moteur_droit_1.value = True
    moteur_gauche_2.value = True
    moteur_droit_2.value = False

# Fonction pour faire tourner le robot vers la droite
def robot_droite() :
    moteur_gauche_1.value = True
    moteur_droit_1.value = False
    moteur_gauche_2.value = False
    moteur_droit_2.value = True

# Fonction pour arrêter le robot
def robot_arret() :
    moteur_gauche_1.value = False
    moteur_droit_1.value = False
    moteur_gauche_2.value = False
    moteur_droit_2.value = False

# instanciation du capteur de distance
capteur_obstacle = adafruit_vl6180x.VL6180X(clue._i2c)

# Robot à l'arrêt au démarrage
robot_arret()
sleep(3)

# ---------------------------------------
# -------  BOUCLE PRINCIPALE  -----------
# ---------------------------------------
while True:
    # Récupération de la mesure du capteur VL6180X
    distance_obstacle_mm = capteur_obstacle.range
    # S'il n'y a pas d'obstacle
    if (distance_obstacle_mm > 120) :
        # Le robot avance tout droit
        robot_tout_droit()
        # Ses yeux regardent droit devant
        groupe_oeil_gauche.x = 0
        groupe_oeil_droit.x = 0
    else :
        # sinon on détermine un sens de rotation aléatoire
        sens = randint(0,1)
        # tant que l'obstacle est dans le champ de vision du robot
        while (capteur_obstacle.range < 120) :
            # on tourne selon le sens aléatoire précédent
            # et les yeux regardent dans la direction de la rotation
            if sens == 0 :
                robot_gauche()
                groupe_oeil_gauche.x = 15
                groupe_oeil_droit.x = 15
            else :
                robot_droite()
                groupe_oeil_gauche.x = -15
                groupe_oeil_droit.x = -15

