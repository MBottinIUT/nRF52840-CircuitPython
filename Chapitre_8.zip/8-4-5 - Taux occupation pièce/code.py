""" CLUE 8.4.5 : Taux d'occupation d'une salle"""
# Importation des modules natifs utiles
from time import *
from board import *
from analogio import *
from displayio import *
from terminalio import *
# importation de modules supplémentaires
from adafruit_clue import clue
from adafruit_display_text import label

# Instanciation d'une broche analogique
laser1 = AnalogIn(A2)
laser2 = AnalogIn(A3)

# Phase de calibration des récepteurs des faisceaux LASER
print ("Calibration : ne coupez pas les faisceaux Laser et appuyez sur A")
while not clue.button_a :
    valeur_laser1_intacte = laser1.value
    valeur_laser2_intacte = laser2.value
sleep(1)
print ("Calibration : coupez les deux faisceaux Laser et appuyez sur A")
while not clue.button_a :
    valeur_laser1_coupe = laser1.value
    valeur_laser2_coupe = laser2.value
print("...")
sleep(1)
print("Phase de calibration terminee")
sleep(3)
print("Demarrage :")

# On fixe les seuils de détection (faisceau intact vs. faisceau coupé)
seuil_laser1 = (valeur_laser1_intacte + valeur_laser1_coupe)//2
seuil_laser2 = (valeur_laser2_intacte + valeur_laser2_coupe)//2

# Instanciation de l'écran
ecran = DISPLAY

# Mise en place et affichage du groupe principal (6 objets max)
groupe_principal = Group(max_size=6)
ecran.show(groupe_principal)

# Mise en place de l'image de fond dans le groupe_principal
fichier = open("/images/Fond_salle.bmp", "rb")
page = OnDiskBitmap(fichier)
tuile_image = TileGrid(page, pixel_shader=ColorConverter(),x=0,y=0)
groupe_principal.append(tuile_image)

# Constante réglable fixant la capacité maximale de la salle surveillée
capacite_maximale = 5

# Création d'un groupe 'effectif' avec un label
groupe_effectif = Group(max_size=4,scale=2)
texte_effectif_max = label.Label(FONT, text="max={}".format(capacite_maximale), max_glyphs=6, color=clue.VIOLET, x=40, y=23)
groupe_effectif.append(texte_effectif_max)
texte_effectif_salle = label.Label(FONT, text="000", max_glyphs=3, color=clue.AQUA, x=65, y=50)
groupe_effectif.append(texte_effectif_salle)
texte_effectif_entrant = label.Label(FONT, text="000", max_glyphs=3, color=clue.AQUA, x=65, y=75)
groupe_effectif.append(texte_effectif_entrant)
texte_effectif_sortant = label.Label(FONT, text="000", max_glyphs=3, color=clue.AQUA, x=65, y=100)
groupe_effectif.append(texte_effectif_sortant)
groupe_principal.append(groupe_effectif)

# Variables
personnes_entrantes = 0
personnes_sortantes = 0
effectif_salle = 0
prec_laser = 0

# ---------------------------------------
# -------  BOUCLE PRINCIPALE  -----------
# ---------------------------------------
while True:
    # Si le laser 1 a été coupé et qu'aucun autre laser n'a été coupé avant
    if (laser1.value > seuil_laser1 and prec_laser==0) :
        prec_laser = 1
    # Si le laser 1 a été coupé et que le laser 2 a été coupé avant
    elif (laser1.value > seuil_laser1 and prec_laser==2) :
        # une personne est sortie
        print("Une personne est sortie")
        # Flash lumineux
        clue.white_leds = True
        sleep(0.02)
        clue.white_leds = False
        sleep(0.5)
        # Incrémentation du nombre de personnes sorties
        personnes_sortantes = personnes_sortantes +1
        prec_laser = 0
    # Si le laser 2 a été coupé et qu'aucun autre laser n'a été coupé avant
    if (laser2.value > seuil_laser2 and prec_laser==0) :
        prec_laser = 2
    # Si le laser 2 a été coupé et que le laser 1 a été coupé avant
    elif (laser2.value > seuil_laser2 and prec_laser==1) :
        # une personne est entrée
        print("Une personne est entree")
        # Flash lumineux
        clue.white_leds = True
        sleep(0.02)
        clue.white_leds = False
        sleep(0.5)
        # Incrémentation du nombre de personnes entrées
        personnes_entrantes = personnes_entrantes +1
        prec_laser = 0
    # Mise à jour des labels d'effectif
    texte_effectif_entrant.text = "%03i" % personnes_entrantes
    texte_effectif_sortant.text = "%03i" % personnes_sortantes
    # Calcul du nombre de personnes dans la salle
    effectif_salle = personnes_entrantes - personnes_sortantes
    # Alarme visuelle (texte en rouge) si la capacité maximale est dépassée
    if effectif_salle > capacite_maximale :
        texte_effectif_salle.color = clue.RED
    else :
        texte_effectif_salle.color = clue.AQUA
    texte_effectif_salle.text = "%03i" % effectif_salle
    sleep(0.1)
