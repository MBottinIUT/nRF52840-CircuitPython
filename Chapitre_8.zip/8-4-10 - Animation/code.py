"""CLUE 8.4.10 : simple animation"""
# importation des modules natifs utiles
from time import *
from board import *
from displayio import *
# importation de modules supplémentaires
from adafruit_clue import clue

# Instanciation de l'écran
ecran = DISPLAY

# Mise en place et affichage du groupe principal (2 objets max)
groupe_principal = Group(max_size=2)
ecran.show(groupe_principal)

# Mise en place de l'image de fond dans le groupe_principal
fichier = open("/images/Fond_animation.bmp", "rb")
fond = OnDiskBitmap(fichier)
tuile_fond = TileGrid(fond, pixel_shader=ColorConverter(),x=0,y=0)
groupe_principal.append(tuile_fond)

# Mise en place du groupe contenant le personnage animé
personnage = Group(scale=1)
fichier = open("/images/Walking.bmp", "rb")
anim = OnDiskBitmap(fichier)
sprite = TileGrid(anim, pixel_shader=ColorConverter(),
                width = 1, height = 1, tile_width = 34, tile_height = 49)
personnage.append(sprite)
groupe_principal.append(personnage)

# positionne le personnage sur l'écran
x_personnage = 110
y_personnage = 100
personnage.x = x_personnage
personnage.y = y_personnage
sens = True
index_sprite = 0

# ---------------------------------------
# -------  BOUCLE PRINCIPALE  -----------
# ---------------------------------------
while True:
    # Déplace le personnage aux nouvelles coordonnées
    personnage.x = x_personnage
    personnage.y = y_personnage
    # Si le bouton B est appuyé
    if clue.button_b:
        sens = True
        # incrémente le déplacement du personnage vers la droite
        x_personnage = x_personnage + 5
        if x_personnage > (239-34) :
            x_personnage = 239-34
        # Animation de marche vers la droite
        sprite[0] = index_sprite % 6
    elif clue.button_a:
        sens = False
        # incrémente le déplacement du personnage vers la gauche
        x_personnage = x_personnage - 5
        if x_personnage < 0 :
            x_personnage = 0
        # Animation de marche vers la gauche
        sprite[0] = 8 + (index_sprite % 6)
    else :
        # Place le personnage en mode arrêt
        if sens == True :
            sprite[0] = 6
        else :
            sprite[0] = 7
    # Incrémentation de l'index d'animation
    index_sprite += 1
    sleep(0.1)
