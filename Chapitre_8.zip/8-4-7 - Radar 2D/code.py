""" CLUE 8.4.7 : RADAR 2D"""
# Importation des modules natifs utiles
from time import *
from board import *
from displayio import *
from pulseio import *
from math import *
from busio import *
# importation de modules supplémentaires
from adafruit_clue import clue
from adafruit_display_shapes.line import Line
from adafruit_progressbar import ProgressBar
from adafruit_motor.servo import *
from adafruit_tfmini import *

# Instanciation de l'écran
ecran = DISPLAY

# Instanciation d'un signal PWM pour contrôler un servomoteur sur la broche A4
servo_pwm = PWMOut(A4, duty_cycle=4915, frequency=50)
# Instanciation d'un objet servo avec une déviation de 180° et les largeurs d'impulsion min & max
servomoteur = Servo(servo_pwm, actuation_range=180, min_pulse=600, max_pulse=2500)

# Instanciation du bus de communication UART
bus_uart = UART(TX, RX)

# Instanciation du capteur de distance LIDAR TF LUNA
capteur_tfluna = TFmini(bus_uart, timeout=1)

# Mise en place et affichage du groupe principal (3 objets max)
groupe_principal = Group(max_size=3)
ecran.show(groupe_principal)

# Mise en place de l'image de fond dans le groupe_principal
fichier = open("/images/Fond_radar.bmp", "rb")
page = OnDiskBitmap(fichier)
tuile_image = TileGrid(page, pixel_shader=ColorConverter(),x=0,y=0)
groupe_principal.append(tuile_image)

# Instanciation d'une barre de progression dans le groupe_principal
barre_distance_obstacle = ProgressBar(40, 76, 164, 15, 0.5, stroke=1, bar_color = clue.GREEN)
groupe_principal.append(barre_distance_obstacle)

# Instanciation du groupe qui va contenir toutes les lignes du balayage radar
groupe_lignes_radar = Group(max_size=50)
groupe_principal.append(groupe_lignes_radar)

# constante
x_centre = 120
y_centre = 220
rayon_radar = 108
# Distance maximale de détection (ici 100 cm) --> réglable par l'utilisateur
distance_maximale_reglable = 100

# ---------------------------------------
# -------  BOUCLE PRINCIPALE  -----------
# ---------------------------------------
while True:
    # On effectue un balayage du servomoteur de 0 à 180° par pas de 2°
    for angle in range(0,180,2) :
        # On bouge le servomoteur selon l'angle angle
        servomoteur.angle = angle
        # On tente de lire la distnace de l'obstacle durant le timeout
        try :
            distance_obstacle_cm = capteur_tfluna.distance
        except :
            distance_obstacle_cm = 0
        # On borne la distance mesurée à la distance maximale
        if distance_obstacle_cm > distance_maximale_reglable :
            distance_obstacle_cm = distance_maximale_reglable
        # Calcul du pourcentage vis-à-vis de la distance maximale
        ratio = distance_obstacle_cm/distance_maximale_reglable
        # On met à jour la barre de progression
        barre_distance_obstacle.progress = ratio
        # On calcule les coordonnées de l'extrémité de la ligne de balayage
        x_ligne = x_centre + int((rayon_radar*ratio)*cos(radians(angle)))
        y_ligne = y_centre - int((rayon_radar*ratio)*sin(radians(angle)))
        # On affiche la ligne correspondant à l'angle et représentant la distance de l'obstacle
        groupe_lignes_radar.append(Line(x_centre, y_centre, x_ligne, y_ligne, clue.GREEN))
        # On ne conserve que les 15 dernières lignes affichées, les autres sont effacées
        if angle>30 :
            groupe_lignes_radar.pop(1)
        sleep(0.05)
    # On repositionne le servomoteur à son point de départ pour un nouveau cycle
    servomoteur.angle = 0
    # pause entre deux balayages
    sleep(2)
    # On efface les dernières lignes affichées
    for i in range(0,15) :
        groupe_lignes_radar.pop(1)
