"""CLUE 8.4.2 : horloge analogique"""
# importation des modules natifs utiles
from board import *
from time import *
from displayio import *
from terminalio import *
from math import *
# importation de modules supplémentaires
from adafruit_clue import clue
from adafruit_display_text import label
from adafruit_display_shapes.line import Line
from adafruit_display_shapes.rect import Rect
from adafruit_display_shapes.triangle import Triangle

# Instanciation de l'écran
ecran = DISPLAY

# Mise en place et affichage du groupe principal (4 objets max)
groupe_principal = Group(max_size=4)
ecran.show(groupe_principal)

# Mise en place du groupe de réglage de l'heure avec ses labels
groupe_reglage = Group(max_size=3, scale=4)
groupe_principal.append(groupe_reglage)
texte_heure = label.Label(FONT, text="00", color=clue.RED, x=12, y=25)
texte_separation = label.Label(FONT, text=":", color=clue.WHITE, x=27, y=25)
texte_minute = label.Label(FONT, text="00", color=clue.WHITE, x=35, y=25)
groupe_reglage.append(texte_heure)
groupe_reglage.append(texte_separation)
groupe_reglage.append(texte_minute)

# Réglage de l'heure
heures=0
minutes=0
# Réglage des heures
while not clue.button_b :
    if clue.button_a:
        heures=heures+1
        if heures==24 :
            heures = 0
        texte_heure.text="%02i" % heures
        sleep(0.2)
texte_heure.color = clue.WHITE
texte_minute.color = clue.RED
sleep(1)
# Réglage des minutes
while not clue.button_b :
    if clue.button_a:
        minutes=minutes+1
        if minutes==60 :
            minutes = 0
        texte_minute.text="%02i" % minutes
        sleep(0.2)

# On cache le groupe de réglage de l'heure
groupe_principal[0].hidden=True

# Mise en place de l'image de fond dans le groupe_principal
fichier = open("/images/Fond_montre.bmp", "rb")
page = OnDiskBitmap(fichier)
tuile_image = TileGrid(page, pixel_shader=ColorConverter(),x=0,y=0)
groupe_principal.append(tuile_image)

# ---------------------------------------
# -------  BOUCLE PRINCIPALE  -----------
# ---------------------------------------
while True:
    # Calcul des angles des aiguilles
    angle_heures = radians(heures * 30) + radians(minutes//2)
    angle_minutes = radians(minutes * 6)
    # Détermination des coordonnées des aiguilles
    X_heures = 120 + int(60*sin(angle_heures))
    Y_heures = 120 - int(60*cos(angle_heures))
    X_minutes = 120 + int(90*sin(angle_minutes))
    Y_minutes = 120 - int(90*cos(angle_minutes))
    # Tracé des deux aiguilles
    petite_aiguille = Triangle(117, 120, 123, 120, X_heures, Y_heures, fill=clue.WHITE, outline=clue.WHITE)
    groupe_principal.append(petite_aiguille)
    grande_aiguille = Triangle(117, 120, 123, 120, X_minutes, Y_minutes, fill=clue.WHITE, outline=clue.WHITE)
    groupe_principal.append(grande_aiguille)
    # Attente de 60 secondes
    sleep(1)
    # Incrémentation des minutes
    minutes = minutes + 1
    # incrémentation des heures si nécessaire
    if minutes == 60 :
        minutes = 0
        heures = (heures + 1)%12
        if heures == 12 :
            heures = 0
    # Suppression des deux aiguilles
    groupe_principal.pop(2)
    groupe_principal.pop(2)
