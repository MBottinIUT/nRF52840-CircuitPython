import morsecode

message = input ("Quel est votre message : ")

morsecode.send(message)
