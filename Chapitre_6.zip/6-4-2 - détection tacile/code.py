""" Programme 6-4-2 Détection capacitive tactile """
# Importation des librairies natives utiles
from board import *
from touchio import *
from pulseio import *

# Instanciation d'un signal PWM pour le piezo sur la broche A2
piezo = PWMOut(A2, duty_cycle=0, frequency=440)

# Instanciation d'un bouton tactile
Touche_tactile = TouchIn(A5)
Touche = True

while True:
    # Teste si la zone conductrice a été touchée
    if (Touche_tactile.value == Touche) :
        # Emet le son la3
        piezo.duty_cycle = 65535 // 2
    else :
        # N'émet aucun son
        piezo.duty_cycle = 0
