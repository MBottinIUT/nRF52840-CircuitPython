# Nul besoin de préciser le type de la variable
nombre1 = 12
nombre2 = 53.85
texte1 = "Michael"
couleur = (255,0,0)
dico = {"1": 45, "2": 89}

# Ne génère pas d'erreur
if nombre1 > nombre2 :
	print("nombre1 est plus grand que nombre2")
else :
	print("nombre2 est plus grand que nombre1")

# Génère une erreur
if nombre4 == 50 :
	print("le nombre4 est egal à 50")