nom = "DUPONT"
age = 47

print("Bonjour, je me nomme " +nom+ " et j'ai " +str(age)+ "ans.")
print("Bonjour, je me nomme %s et j'ai %d ans." % (nom,age))    
print("Bonjour, je me nomme {} et j'ai {} ans.".format(nom,age))  