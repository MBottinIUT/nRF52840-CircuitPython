if (mon_test1):
   	print("test 1 valide")
	if (mon_test2):
		print("test 2 valide")
	else :
		print("test 2 non valide")
else:
  	print("test 1 non valide")