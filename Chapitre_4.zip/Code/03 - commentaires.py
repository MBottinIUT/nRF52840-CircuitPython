""" il s'agit
	d'un commentaire
	sur plusieurs
	lignes """

print ("Bonjour")
# Il s'agit d'un commentaire sur une seule lignes
print ("Au revoir")
