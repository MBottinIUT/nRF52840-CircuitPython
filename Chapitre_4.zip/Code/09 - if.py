if (test1) :
	instruction 1
	instruction 2
	...
elif (test2) :
	instruction 3
	instruction 4
	...
else :
	instruction 5
	instruction 6
	...