while (test) :
	instruction 1
	instruction 2
	...