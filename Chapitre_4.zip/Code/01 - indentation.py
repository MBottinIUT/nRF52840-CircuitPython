if (mon_test):
   	print("test valide")
   	print("test toujours valide")
else:
  	print("test non valide")
   	print("test toujours non valide")