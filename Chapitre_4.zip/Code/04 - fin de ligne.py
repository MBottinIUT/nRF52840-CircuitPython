# utilisation du caractère de commutation de ligne \

nombre1 = 12
nombre2 = 24
nombre3 = 36

somme = nombre1 + \
		nombre2 + \
		nombre3

print(somme)
