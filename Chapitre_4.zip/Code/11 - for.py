for i in range (0, 17, 2) :
	instruction 1
	instruction 2
	...