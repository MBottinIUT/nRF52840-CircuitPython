nombre1 = 53.85
nombre2 = int(nombre1)

print(nombre1)
print(nombre2)        