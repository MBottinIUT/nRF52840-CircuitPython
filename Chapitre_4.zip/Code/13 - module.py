import math

a = 45

print ("sinus de {} ° : {}". format(a,math.sin(a)))
print ("cosinus de {} ° : {}". format(a,math.cos(a)))