"""7-12-2 : instrument MIDI VS1053"""
# Importation des modules natifs utiles
from time import *
from board import *
from touchio import *
from busio import *

# Instanciation d'une liaison UART avec la vitesse du MIDI
midi = UART(TX, RX, baudrate=31250)

# Liste des broches utilisées pour les zones tactiles
broches = [D12, D11, A5, A4, A3, A2, A1]

# Instanciation de toutes les broches tactiles
zones_contact = [TouchIn(broche) for broche in broches]

# Liste des notes (MIDI) associées à chaque broche tactile
notes_midi = [40, 35, 38, 41, 55, 31, 50]

# Configuration du VS1053
# Sélection de la banque percussions
midi.write(bytes([0xB0, 0x00, 0x78]))

# ---------------------------------------
# -------  BOUCLE PRINCIPALE  -----------
# ---------------------------------------
while True:
    # Balayage de toutes les zones tactiles
    for index, zone in enumerate(zones_contact):
        # Détermination de la note selon la zone
        note = notes_midi[index]
        # Si la zone de contact est touchée
        if zone.value == True:
            # on envoie la commande MIDI 'note on' au VS1053
            midi.write(bytes([0x90, note, 0x7F]))
        else:
            # on envoie la commande MIDI 'note off' au VS1053
            midi.write(bytes([0x80, note, 0x00]))
    sleep(0.1)