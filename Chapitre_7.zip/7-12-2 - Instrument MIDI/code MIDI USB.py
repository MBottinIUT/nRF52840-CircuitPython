"""7-12-2 : instrument MIDI USB"""
# Importation des modules natifs utiles
from time import *
from board import *
from touchio import *
import usb_midi
# importation de modules supplémentaires
import adafruit_midi
from adafruit_midi.note_on import NoteOn
from adafruit_midi.note_off import NoteOff

# Instanciation du module MIDI
midi_channel = 0
midi = adafruit_midi.MIDI(midi_out=usb_midi.ports[1],
                          out_channel=midi_channel)

# Liste des broches utilisées pour les zones tactiles
broches = [D12, D11, A5, A4, A3, A2, A1]

# Instanciation de toutes les broches tactiles
zones_contact = [TouchIn(broche) for broche in broches]

# Paramètres MIDI
octave = 2
velocity = 127
# Liste des notes (MIDI) associées à chaque broche tactile
notes_midi = [48, 50, 52, 53, 55, 57, 59]

# ---------------------------------------
# -------  BOUCLE PRINCIPALE  -----------
# ---------------------------------------
while True:
    # Balayage de toutes les zones tactiles
    for index, zone in enumerate(zones_contact):
        # Détermination de la note selon la zone
        note = notes_midi[index] + octave * 12
        # Si la zone de contact est touchée
        if zone.value == True:
            # on envoie la commande 'note on' en MIDI
            midi.send(NoteOn(note, velocity))
        else:
            # sinon on envoie la commande 'note off' en MIDI
            midi.send(NoteOff(note, velocity))
    sleep(0.1)