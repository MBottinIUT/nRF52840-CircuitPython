""" projet 7-5-2 enregistreur de température """
# importation des modules natifs utiles
from board import *
from time import *
from digitalio import *
from storage import *
# importation de modules supplémentaires
from adafruit_bmp280 import *
from adafruit_sht31d import *
from adafruit_pcf8523 import *
from busio import *
from adafruit_sdcard import *

# Instanciation de la LED (D13 correspond à la LED intégrée sur le module)
Led = DigitalInOut(D13)
Led.direction = Direction.OUTPUT

# Instanciation du bouton (SWITCH correspond au bouton intégré sur le module)
Bouton = DigitalInOut(SWITCH)
Bouton.direction = Direction.INPUT
Bouton.pull = Pull.UP

# Instanciation du bus de communication I2C sur le module Feather
bus_i2c = I2C(SCL, SDA)
# Instanciation d'un des deux capteurs de température du module Feather
capteur_bmp280 = Adafruit_BMP280_I2C(bus_i2c)
# Instanciation de la RTC PCF8523 sur la FeatherWIng Adalogger
horloge_temps_reel = PCF8523(bus_i2c)
# Instanciation du bus de communication SPI sur le module Feather
bus_spi = SPI(SCK, MOSI, MISO)
# Instanciation de la carte SD et montage du volume avec le nom 'sd'
SD_CS = DigitalInOut(D10)
carte_sd = SDCard(bus_spi, SD_CS)
vfs = VfsFat(carte_sd)
mount(vfs, "/sd")

# Mise à l'heure (+date) si le bouton 'user' est appuyé au démarrage
if Bouton.value == False :
    #                     year, mon, date, hour, min, sec, wday, yday, isdst
    h = time.struct_time((2020,  05,   08,   00,  27,  00,    0,   -1,    -1))
    print("Enregistre l'heure : ", h)
    horloge_temps_reel.datetime = h
    print()

# variables globales
nombre_mesures = 20
numero_mesure = 0
pas = 3

# ---------------------------------------
# -------  BOUCLE PRINCIPALE  -----------
# ---------------------------------------
Led.value = True
# Boucle pour enregistrer les 'nombre_mesures' valeurs de température
while numero_mesure < nombre_mesures:
    try:
        # On ouvre le fichier 'temp.csv' en mode 'append'
        with open("/sd/temp.csv", "a") as enregistrement:
            # Récupération de l'heure actuelle
            h = horloge_temps_reel.datetime
            # Affichage de l'heure actuelle pour info
            heure = "{}:{}:{}".format(h.tm_hour, h.tm_min, h.tm_sec)
            print("Heure actuelle : {}".format(heure))
            # Lecture et affichage de la température
            temperature = "{:.1f}".format(capteur_bmp280.temperature)
            temperature.replace('.',',')
            print("Temperature={}C".format(temperature))
            print()
            # enregistrement des informations heure/température dans le fichier
            enregistrement.write("{}; {}\n".format(heure, temperature))
        # Attente entre deux mesures
        sleep(pas)
        # Incrémentation de l'indice de la mesures
        numero_mesure = numero_mesure +1
    # incapicité d'accéder à la carte SD
    except OSError:
        pass
# Message de fin d'enregistrement
print ("\nEnregistrement termine !!")
Led.value = False
