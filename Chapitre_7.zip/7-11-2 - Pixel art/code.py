""" programme 7-11-2 : Pixel Art"""
# Importation des modules natifs utiles
from time import *
from board import *
from random import *
from displayio import *
from framebufferio import *
from rgbmatrix import *

# Libère toute ressource déjà utilisée par displayio
release_displays()

# Instanciation de la matrice 32x32
matrice = RGBMatrix(width=32, height=32, bit_depth=3, rgb_pins=[D6, SDA, D9, D11, D10, D12],
                addr_pins=[A5, A4, A3, A2], clock_pin=D2, latch_pin=RX, output_enable_pin=TX)
# Instanciation de l'affichage
affichage = FramebufferDisplay(matrice, auto_refresh=True)

# Mise en place de la première image de l'animation Spiderman
# Création du groupe pour contenir la première image
groupe_spider1 = Group(max_size=1)
# Ouverture du fichier
spider_file1 = open("images/Spiderman1.bmp", 'rb')
# Extraction des données uniquement liées à l'image depuis le fichier du disque
spider_bmp1 = OnDiskBitmap(spider_file1)
# Création d'une tuile image basée sur le bitmap 'spider_bmp1'
tuile_spiderman1 = TileGrid(spider_bmp1, pixel_shader=ColorConverter())
# Ajoute cette tuile image au groupe de la première image
groupe_spider1.append(tuile_spiderman1)

# Mise en place de la deuxième image de l'animation Spiderman
groupe_spider2 = Group(max_size=1)
spider_file2 = open("images/Spiderman2.bmp", 'rb')
spider_bmp2 = OnDiskBitmap(spider_file2)
tuile_spiderman2 = TileGrid(spider_bmp2, pixel_shader=ColorConverter())
groupe_spider2.append(tuile_spiderman2)

# Mise en place de la troisième image de l'animation Spiderman
groupe_spider3 = Group(max_size=1)
spider_file3 = open("images/Spiderman3.bmp", 'rb')
spider_bmp3 = OnDiskBitmap(spider_file3)
tuile_spiderman3 = TileGrid(spider_bmp3, pixel_shader=ColorConverter())
groupe_spider3.append(tuile_spiderman3)

# Mise en place de la quatrième image de l'animation Spiderman
groupe_spider4 = Group(max_size=1)
spider_file4 = open("images/Spiderman4.bmp", 'rb')
spider_bmp4 = OnDiskBitmap(spider_file4)
tuile_spiderman4 = TileGrid(spider_bmp4, pixel_shader=ColorConverter())
groupe_spider4.append(tuile_spiderman4)

# Mise en place de l'image du Joker
groupe_joker = Group(max_size=1)
joker_file = open("images/Joker.bmp", 'rb')
joker_bmp = OnDiskBitmap(joker_file)
tuile_joker = TileGrid(joker_bmp, pixel_shader=ColorConverter())
groupe_joker.append(tuile_joker)

# Affichage de l'image du Joker pendant 3 secondes
affichage.show(groupe_joker)
affichage.refresh()
sleep(3)

# ---------------------------------------
# -------  BOUCLE PRINCIPALE  -----------
# ---------------------------------------
while True:
    # Animation de Spiderman : affichage de la séquence d'images
    # avec une pause entre chaque, la première étant de durée aléatoire
    affichage.show(groupe_spider1)
    affichage.refresh()
    sleep(randint(1,6))
    affichage.show(groupe_spider2)
    affichage.refresh()
    sleep(0.1)
    affichage.show(groupe_spider3)
    affichage.refresh()
    sleep(0.1)
    affichage.show(groupe_spider4)
    affichage.refresh()
    sleep(0.1)
