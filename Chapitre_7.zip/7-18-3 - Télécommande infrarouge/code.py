"""programme 7-17-3 : télécommande infrarouge"""
# importation des modules natifs utiles
from time import *
from board import *
from busio import *
from digitalio import *
from pulseio import *
# importation de modules supplémentaires
import adafruit_irremote
from adafruit_max7219 import matrices

# Instanciation de la partie décodage infrarouge (IR Click Board)
reception_ir = PulseIn(A0, maxlen=120, idle_state=True)
decodeur_ir = adafruit_irremote.GenericDecode()

# Instanciation de l'affichage matriciel 8x8 via MAX7219 (8x8R Click Board)
cs = DigitalInOut(D10)
spi = SPI(SCK, MOSI, MISO)
display = matrices.Matrix8x8(spi, cs)
# Fixe la luminosité de l'affichage matriciel
display.brightness(3)

# Dictionnaire contenant les codes de la télécommande (HAIER TV ici)
codes_chiffres={"0":[223,32,247,8],"1":[223,32,119,136],"2":[223,32,183,72],\
                "3":[223,32,55,200],"4":[223,32,215,40],"5":[223,32,87,168],\
                "6":[223,32,151,104],"7":[223,32,23,232],"8":[223,32,231,24],\
                "9":[223,32,103,152]}

# ---------------------------------------
# -------  BOUCLE PRINCIPALE  -----------
# ---------------------------------------
while True:
    # On lit les impulsions provenant d'une trame infrarouge
    pulses = decodeur_ir.read_pulses(reception_ir)
    #print("Heard", len(pulses), "Pulses:", pulses)
    # On essaie de décoder cette trame
    try:
        # On récupère le code reçu
        code_recu = decodeur_ir.decode_bits(pulses)
        print("Code recu : ", code_recu)
    # exception concernant un code plus court dans le protocole NEC
    except adafruit_irremote.IRNECRepeatException:
        print("NEC touche repetition!")
    # exception lorsque le décodage a échoué
    except adafruit_irremote.IRDecodeException as e:
        print("Le decodage a echoue: ", e.args)
    print("----------------------------")
    # Efface la matrice
    display.fill(0)
    # On parcourt l'ensemble des codes enregistrés
    for c,code in codes_chiffres.items() :
        # si le code reçu est identique à un code enregistré
        if code_recu == code :
            # alors on affiche le caractère correspondant sur la matrice
            display.text(c,0,0)
    # Rafraîchissement de la matrice
    display.show()