"""programme 7-16-2 : commande d'un robot roulant"""
# importation des modules natifs utiles
from time import *
# importation de modules supplémentaires
from adafruit_motorkit import MotorKit

# Instanciation de la carte d'extension Featherwing DC Motor
carte_dc_motor = MotorKit()

# MOTEUR DROIT = MOTEUR 3
# MOTEUR GAUCHE = MOTEUR 4

# Marche avant
carte_dc_motor.motor3.throttle = 1.0
carte_dc_motor.motor4.throttle = 1.0
sleep(0.5)
# Arret
carte_dc_motor.motor3.throttle = 0
carte_dc_motor.motor4.throttle = 0
sleep(0.5)
# Marche arrière
carte_dc_motor.motor3.throttle = -1.0
carte_dc_motor.motor4.throttle = -1.0
sleep(0.5)
# Arret
carte_dc_motor.motor3.throttle = 0
carte_dc_motor.motor4.throttle = 0
sleep(0.5)
# Tourne à droite
carte_dc_motor.motor3.throttle = -1.0
carte_dc_motor.motor4.throttle = 1.0
sleep(0.5)
# Arret
carte_dc_motor.motor3.throttle = 0
carte_dc_motor.motor4.throttle = 0
sleep(0.5)
# Tourne à gauche
carte_dc_motor.motor3.throttle = 1.0
carte_dc_motor.motor4.throttle = -1.0
sleep(0.5)
# Arret
carte_dc_motor.motor3.throttle = 0
carte_dc_motor.motor4.throttle = 0
sleep(0.5)