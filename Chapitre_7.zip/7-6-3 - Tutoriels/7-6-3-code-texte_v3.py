""" 7-6-2 : Affichage d'un texte avec police BDF """
# importation des modules natives utiles
from time import *
from board import *
from displayio import *
from terminalio import *
# importation de modules supplémentaires
from adafruit_il0373 import *
from adafruit_display_text import label
from adafruit_bitmap_font import bitmap_font

# Déclaration des couleurs
NOIR = 0x000000
BLANC = 0xFFFFFF
ROUGE = 0xFF0000

# Libère toute ressource déjà utilisée par displayio
displayio.release_displays()

# Instanciation du bus de communication SPI sur le module Feather
bus_spi = SPI()
epd_cs = D9
epd_dc = D10
epd_reset = D5
epd_busy = D6

# Instanciation de l'écran e-Paper IL0373 (3 couleurs - 3ème couleur = ROUGE)
bus_affichage = FourWire(bus_spi, command=epd_dc, chip_select=epd_cs,
                                 reset=epd_reset, baudrate=1000000)
sleep(1)
ecran = IL0373(bus_affichage, width=212, height=104, rotation=90, 
				busy_pin=epd_busy, highlight_color=ROUGE)

# Création du groupe général pour l'écran
groupe = Group(max_size=2)

# Création d'un bitmap pour le fond de la résolution de l'écran avec 1 bit/pixel
fond = Bitmap(212, 104, 1)

# Création d'une palette ne contenant qu'une couleur
palette = Palette(1)
# Fixe la couleur de la palette
palette[0] = BLANC

# Création d'une tuile remplie par le bitmap de fond et de couleur 'palette'
tuile_fond = TileGrid(fond, pixel_shader=palette)
# Ajoute cette tuile au groupe général
groupe.append(tuile_fond)

# Chargement de la police bdf
police = bitmap_font.load_font("/fonts/Elektora-36.bdf")

# Création d'un groupe pour l'ensemble du texte
groupe_texte = Group(max_size=2, scale=1)
# Création du label 'ELEKTOR' basée sur la police "Elektora-36.bdf"
# et de couleur 'ROUGE' puis ajout au groupe du texte
titre1 = label.Label(police, text="Elektor", x=0, y=28, color=ROUGE)
groupe_texte.append(titre1)
# Création du label 'MAG' basée sur la police "Elektora-36.bdf"
# et de couleur 'NOIR' puis ajout au groupe du texte
titre2 = label.Label(police, text="Mag", x=60, y=75, color=NOIR)
groupe_texte.append(titre2)
# Ajout du groupe du texte au groupe général
groupe.append(groupe_texte)

# Affiche le groupe général sur l'écran
ecran.show(groupe)

# Rafraîchissement complet de l'écran (tous les groupes seront rafraîchis)
# NOTE: 1 rafraichissement max / 180 secondes
ecran.refresh()

# Boucle infinie
while True:
    pass
