""" 7-6-3 : Affichage d'un texte avec police intégrée """
# importation des modules natifs utiles
from time import *
from board import *
from displayio import *
from terminalio import *
# importation de modules supplémentaires
from adafruit_il0373 import *
from adafruit_display_text import label
from adafruit_bitmap_font import bitmap_font

# Déclaration des couleurs
NOIR = 0x000000
BLANC = 0xFFFFFF
ROUGE = 0xFF0000

# Libère toute ressource déjà utilisée par displayio
displayio.release_displays()

# Instanciation du bus de communication SPI sur le module Feather
bus_spi = SPI()
epd_cs = D9
epd_dc = D10
epd_reset = D5
epd_busy = D6

# Définition de l'écran
DISPLAY_WIDTH = 212
DISPLAY_HEIGHT = 104
FOREGROUND_COLOR = ROUGE
BACKGROUND_COLOR = BLANC

# Instanciation de l'écran e-Paper IL0373 (3 couleurs - 3ème couleur = ROUGE)
display_bus = FourWire(bus_spi, command=epd_dc, chip_select=epd_cs,
                                 reset=epd_reset, baudrate=1000000)
sleep(1)
display = IL0373(display_bus, width=DISPLAY_WIDTH, height=DISPLAY_HEIGHT,
                                 rotation=90, busy_pin=epd_busy,
                                 highlight_color=ROUGE)

# Create a display group for our screen objects
groupe = Group(max_size=10)

# Set a background
background_bitmap = Bitmap(DISPLAY_WIDTH, DISPLAY_HEIGHT, 1)
# Map colors in a palette
palette = Palette(1)
palette[0] = BACKGROUND_COLOR

# Create a Tilegrid with the background and put in the displayio group
tuile_texte = TileGrid(background_bitmap, pixel_shader=palette)
groupe.append(tuile_texte)

# Draw simple text using the built-in font into a displayio group
text_group1 = Group(max_size=10, scale=2, x=120, y=30)
text1 = "Take"
text_area1 = label.Label(FONT, text=text1, color=FOREGROUND_COLOR)
text_group1.append(text_area1)  # Add this text to the text group
groupe.append(text_group1)

text_group2 = Group(max_size=10, scale=2, x=100, y=50)
text2 = "care of"
text_area2 = label.Label(FONT, text=text2, color=FOREGROUND_COLOR)
text_group2.append(text_area2)  # Add this text to the text group
groupe.append(text_group2)

text_group3 = Group(max_size=10, scale=2, x=85, y=70)
text3 = "the earth"
text_area3 = label.Label(FONT, text=text3, color=FOREGROUND_COLOR)
text_group3.append(text_area3)  # Add this text to the text group
groupe.append(text_group3)

# Place the display group on the screen
display.show(groupe)

# Refresh the display to have everything show on the display
# NOTE: Do not refresh eInk displays more often than 180 seconds!
display.refresh()

sleep(120)

while True:
    pass
