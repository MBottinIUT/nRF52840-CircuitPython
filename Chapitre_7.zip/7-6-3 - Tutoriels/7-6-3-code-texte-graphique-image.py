""" 7-6-3 : Affichage d'un texte avec police intégrée
                + graphiques + image """
# importation des modules natives utiles
from time import *
from board import *
from displayio import *
from terminalio import *
# importation de modules supplémentaires
from adafruit_il0373 import *
from adafruit_display_text import label
from adafruit_display_shapes.triangle import Triangle

# Déclaration des couleurs
NOIR = 0x000000
BLANC = 0xFFFFFF
ROUGE = 0xFF0000

# Libère toute ressource déjà utilisée par displayio
displayio.release_displays()

# Instanciation du bus de communication SPI sur le module Feather
bus_spi = SPI()
epd_cs = D9
epd_dc = D10
epd_reset = D5
epd_busy = D6

# Instanciation de l'écran e-Paper IL0373 (3 couleurs - 3ème couleur = ROUGE)
bus_affichage = FourWire(bus_spi, command=epd_dc, chip_select=epd_cs,
                                 reset=epd_reset, baudrate=1000000)
sleep(1)
ecran = IL0373(bus_affichage, width=212, height=104, rotation=90,
                    busy_pin=epd_busy, highlight_color=ROUGE)

# Création du groupe général pour l'écran
groupe = Group(max_size=5)

# Création d'un bitmap pour le fond de la résolution de l'écran avec 1 bit/pixel
fond = Bitmap(212, 104, 1)

# Création d'une palette ne contenant qu'une couleur pour le fond
palette = Palette(1)
# Fixe la couleur de la palette
palette[0] = BLANC

# Création d'une tuile remplie par le bitmap de fond et de couleur 'palette'
tuile_fond = TileGrid(fond, pixel_shader=palette)
# Ajoute cette tuile au groupe général
groupe.append(tuile_fond)

# Ajout d'une image
# Ouverture du fichier
fichier = open("/images/Earth_in_hand.bmp", "rb")
# Extraction des données uniquement liées à l'image depuis le fichier du disque
logo = OnDiskBitmap(fichier)
# Création d'une tuile image basée sur le bitmap 'logo'
tuile_image = TileGrid(logo, pixel_shader=ColorConverter(),x=0,y=0)
# Ajout de la tuile image au groupe général
groupe.append(tuile_image)

# Ajout des triangles avant le texte pour qu'ils soient "en-dessous"
triangle1 = Triangle(150, 7, 210, 90, 91, 90, fill=BLANC, outline=NOIR)
groupe.append(triangle1)
triangle2 = Triangle(150, 11, 206, 88, 95, 88, fill=BLANC, outline=NOIR)
groupe.append(triangle2)

# Création d'un groupe pour l'ensemble du texte
groupe_texte = Group(max_size=3, scale=2)
# Création du label 'Take' basée sur la police FONT de terminalio
# et de couleur ROUGE puis ajout au groupe du texte
ligne1 = label.Label(FONT, text="Take", x=63, y=15,color=ROUGE)
groupe_texte.append(ligne1)
# Création du label 'care of' basée sur la police FONT de terminalio
# et de couleur ROUGE puis ajout au groupe du texte
ligne2 = label.Label(FONT, text="care of", x=55, y=26, color=ROUGE)
groupe_texte.append(ligne2)
# Création du label 'the earth' basée sur la police FONT de terminalio
# et de couleur ROUGE puis ajout au groupe du texte
ligne3 = label.Label(FONT, text="the earth", x=48, y= 37, color=ROUGE)
groupe_texte.append(ligne3)
# Ajout du groupe du texte au groupe général
groupe.append(groupe_texte)

# Affiche le groupe général sur l'écran
ecran.show(groupe)

# Rafraîchissement complet de l'écran (tous les groupes seront rafraîchis)
# NOTE: 1 rafraichissement max / 180 secondes
ecran.refresh()

# Boucle infinie
while True:
    pass
