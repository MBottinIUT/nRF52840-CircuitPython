""" programme 7-9-3 : Thermomètre Neopixel"""
# Importation des modules natifs utiles
from time import *
from board import *
from digitalio import *
# importation de modules supplémentaires
from neopixel import *
from simpleio import *
from adafruit_bmp280 import *

# Instanciation de la broche de validation générale de la Featherwing Prop Maker
enable = DigitalInOut(D10)
enable.direction = Direction.OUTPUT
enable.value = True

# Instanciation du ruban Neopixel à 20 LED
led = NeoPixel(D5, 20, brightness=0.2)

# Instanciation du bus de communication I2C sur le module Feather
bus_i2c = I2C()
# Instanciation des deux capteurs qui nous intéressent (connectés sur le bus I2C)
capteur_bmp280 = Adafruit_BMP280_I2C(bus_i2c)

# Création du gradient de couelus sur les 20 LED
gradient_couleur=((0,16,255),(0,62,255),(0,123,255),(0,175,255),(0,224,255),\
                (0,253,234),(0,255,182),(0,255,117),(0,255,57),(0,255,8),\
                (21,255,0),(82,255,0),(145,255,0),(210,255,0),(251,255,0),
                (255,223,0),(255,161,0),(255,101,0),(255,44,0),(255,7,0))

# ---------------------------------------
# -------  BOUCLE PRINCIPALE  -----------
# ---------------------------------------
while True :
    # Lecture de la température du capteur BMP280
    Temperature = capteur_bmp280.temperature
    print(Temperature)
    # Limitation de la plage de température :
    if Temperature < -20.0 :
        Temperature = 20.0
    if Temperature > 40.0 :
        Temperature = 40.0
    # Mise à l'échelle de la température sur les 20 LED
    Temperature = int(map_range(Temperature,-20,40,0,19))
    # Mise à jour de l'affichage des LED selon la température
    for i in range (0,Temperature+1) :
        led[i] = gradient_couleur[i]
    for i in range (Temperature+1,len(gradient_couleur)) :
        led[i] = (0,0,0)
    # Attente d'une seconde
    sleep(1)

