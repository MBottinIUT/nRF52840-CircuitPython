""" Projet 7-4-2 : station météo locale """
# importation des modules natives utiles
from board import *
from time import *
# importation de modules supplémentaires
from adafruit_bmp280 import *
from adafruit_sht31d import *
from dotstar_featherwing import *
from font3 import *

# Instanciation du bus de communication I2C sur le module Feather
bus_i2c = I2C()
# Instanciation des deux capteurs qui nous intéressent (connectés sur le bus I2C)
capteur_bmp280 = Adafruit_BMP280_I2C(bus_i2c)
capteur_sht30 = SHT31D(bus_i2c)
# Instanciation de la matrice de LED Dotstar (avec broches clock et data)
matrice = DotstarFeatherwing(D13, D11)

# Fixe la valeur de la pression atmosphérique actuelle (hPa) au niveau de la mer
#             --> nécessaire pour le calcul de l'altitude
capteur_bmp280.sea_level_pressure = 1014

# Couleurs choisies pour chaque message
orange = (171,118,3)
rose = (148,3,161)
bleu = (3,77,161)

# ---------------------------------------
# -------  BOUCLE PRINCIPALE  -----------
# ---------------------------------------
while True:
    # Mise en forme du message de la température et défilement
    matrice.clear()
    message_temperature = "Temperature={:.1f}°C".format(capteur_bmp280.temperature)
    matrice.shift_in_string(font, message_temperature, orange, 0.05)
    sleep(0.5)
    # Mise en forme du message de la pression atmosphérique et défilement
    matrice.clear()
    message_pression = "Pression Atmospherique={}hPa".format(capteur_bmp280.pressure)
    matrice.shift_in_string(font, message_pression, rose, 0.05)
    sleep(0.5)
    # Mise en forme du message de l'humidité et défilement
    matrice.clear()
    message_humidite = "Humidite={:.1f}%".format(capteur_sht30.relative_humidity)
    matrice.shift_in_string(font, message_humidite, bleu, 0.05)
    sleep(0.5)
