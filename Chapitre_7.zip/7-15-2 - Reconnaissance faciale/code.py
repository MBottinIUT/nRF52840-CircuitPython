"""programme 7-15-2 : commande avec reconnaissance faciale"""
# importation des modules natifs utiles
from time import *
from board import *
from busio import *
from digitalio import *

# Instanciation de la commande du relais
Relais = DigitalInOut(A0)
Relais.direction = Direction.OUTPUT
Relais.value = False

# Instanciation du bus de communication UART sur le module Feather
huskylens = UART(TX, RX, baudrate=9600)

# Commandes de camera Huskylens
Message_knock = bytearray([0x55, 0xAA, 0x11, 0x00, 0x2C, 0x3C])
Message_recherche_ID1 = bytearray([0x55, 0xAA, 0x11, 0x02, 0x27, 0x01, 0x00, 0x3A])

# Test si la communication avec la caméra est correcte
camera_ok = False
while camera_ok == False :
    print("tentative de connexion a la camera...")
    #â envoi de la commande 'knock'
    huskylens.write(Message_knock)
    # Lecture des 6 octets de la réponse
    reponse = huskylens.read(6)
    # si la réponse existe et a la bonne longueur
    if (reponse != None and len(reponse)==6):
        # et si la réponse contient les bons octets
        if (reponse[0]==0x55 and reponse[1]==0xAA and reponse[2]==0x11 and reponse[4]==0x2E) :
            # alors la caméra est opérationnelle
            camera_ok = True
    sleep(1)

print("camera connectee...")
sleep(1)

print("Enregistrer un visage....\n")

# ---------------------------------------
# -------  BOUCLE PRINCIPALE  -----------
# ---------------------------------------
while True:
    # demande a la camera si visage a ete detecte (recherche de l'ID1)
    huskylens.write(Message_recherche_ID1)
    # Lecture des 16 octets de la réponse
    reponse = huskylens.read(16)
    # Si la réponse correspond à 'COMMAND_RETURN_OK'
    if (reponse[0]==0x55 and reponse[1]==0xAA and reponse[2]==0x11 and reponse[4]==0x29 and reponse[5]!=0x00) :
        # alors on lit les 16 octets suivants
        reponse = huskylens.read(16)
        # Si la réponse correspond à 'COMMAND_RETURN_BLOCK' et que l'ID du bloc est 1
        if (reponse[0]==0x55 and reponse[1]==0xAA and reponse[2]==0x11 and reponse[4]==0x2A and reponse[13]==0x01) :
            # c'est que le visage enregistré a été détecté
            print ("visage ID1 detecte...")
            # on alterne la commande du relais
            Relais.value = not Relais.value
            sleep(3)
        else :
            print ("autre visage detecte...")
    else :
        print ("aucun visage connu n'a ete detecte !")
    sleep(0.5)