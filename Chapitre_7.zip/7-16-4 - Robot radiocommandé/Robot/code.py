"""programme 7-16-4 : robot roulant télécommandé RFM69"""
# importation des modules natives utiles
from time import *
from board import *
from busio import *
from digitalio import *
# importation de modules supplémentaires
from adafruit_motorkit import MotorKit
from adafruit_rfm69 import RFM69

# Instanciation de la carte d'extension Featherwing DC Motor
carte_dc_motor = MotorKit()

# Précise la fréquence utilisée par le module radio RFM69
RADIO_FREQ_MHZ = 433.0

# Broches supplémentaires nécessaires à la Featherwing RFM69
CS_RFM69 = DigitalInOut(D5)
RESET_RFM69 = DigitalInOut(D6)

# Instancie la LED interne comme indicateur visual
LED = DigitalInOut(D13)
LED.direction = Direction.OUTPUT
LED.value = False       # non connecté

# Instanciation du bus SPI
bus_spi = SPI(SCK, MOSI=MOSI, MISO=MISO)

# Instanciation de la Featherwing RFM69
rfm69 = RFM69(bus_spi, CS_RFM69, RESET_RFM69, RADIO_FREQ_MHZ)

# Clé de cryptage des messages
rfm69.encryption_key = (
    b"\x01\x02\x03\x04\x05\x06\x07\x08\x01\x02\x03\x04\x05\x06\x07\x08")

# Indique que la connexion est établie avec la Featherwing RFM69
LED.value = True
print ("connexion etablie...")
print("Pour verification - Frequence: {0}MHz".format(rfm69.frequency_mhz))

# MOTEUR DROIT = MOTEUR 3
# MOTEUR GAUCHE = MOTEUR 4

# ---------------------------------------
# -------  BOUCLE PRINCIPALE  -----------
# ---------------------------------------
while True:
    # Réception de données du module RFM69 avec un timeout de 100ms
    donnee = rfm69.receive(timeout=0.1)
    # Si rien n'a été reçu avant la fin des 100ms
    if donnee is None:
        # Aucune donnée n'a ete recue
        LED.value = False
        # Arret du robot
        carte_dc_motor.motor3.throttle = 0
        carte_dc_motor.motor4.throttle = 0
        print("Rien recu ! Nouvelle tentative...")
    # ou si des données ont été reçues
    else:
        # visualise la fait d'avoir recu des données
        LED.value = True
        # affiche les données brutes reçues (octets)
        print("Recus (octets): {0}".format(donnee))
        # Décodage ASCII des données brutes
        donnee_text = str(donnee, "ascii")
        # Affichage des données ASCII
        print("Reçus (ASCII): {0}".format(donnee_text))
        if donnee_text == "Avant\r\n" :
            # Marche avant
            carte_dc_motor.motor3.throttle = 1.0
            carte_dc_motor.motor4.throttle = 1.0
        elif donnee_text == "Arriere\r\n" :
            # Marche arrière
            carte_dc_motor.motor3.throttle = -1.0
            carte_dc_motor.motor4.throttle = -1.0
        elif donnee_text == "Droite\r\n" :
            # Tourne à droite
            carte_dc_motor.motor3.throttle = -1.0
            carte_dc_motor.motor4.throttle = 1.0
        elif donnee_text == "Gauche\r\n" :
            # Tourne à gauche
            carte_dc_motor.motor3.throttle = 1.0
            carte_dc_motor.motor4.throttle = -1.0
        else :
            # Arret
            carte_dc_motor.motor3.throttle = 0
            carte_dc_motor.motor4.throttle = 0