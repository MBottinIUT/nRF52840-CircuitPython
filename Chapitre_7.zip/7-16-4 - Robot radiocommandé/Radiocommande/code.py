"""7-16-4 : télécommande RFM69"""
# Importation des modules natifs utiles
from time import *
from board import *
from busio import *
from digitalio import *
# importation de modules supplémentaires
from adafruit_featherwing import joy_featherwing
from adafruit_rfm69 import RFM69

# instanciation de la carte d'extension JoyWing
carte_joywing = joy_featherwing.JoyFeatherWing()

# Précise la fréquence utilisée par le module radio RFM69
RADIO_FREQ_MHZ = 433.0

# Broches supplémentaires nécessaires à la Featherwing RFM69
CS_RFM69 = DigitalInOut(D5)
RESET_RFM69 = DigitalInOut(D6)

# Instancie la LED interne comme indicateur visual
LED = DigitalInOut(D13)
LED.direction = Direction.OUTPUT
LED.value = False       # non connecté

# Instanciation du bus SPI
bus_spi = SPI(SCK, MOSI=MOSI, MISO=MISO)

# Instanciation de la Featherwing RFM69
rfm69 = RFM69(bus_spi, CS_RFM69, RESET_RFM69, RADIO_FREQ_MHZ)

# Clé de cryptage des messages
rfm69.encryption_key = (
    b"\x01\x02\x03\x04\x05\x06\x07\x08\x01\x02\x03\x04\x05\x06\x07\x08")

# Indique que la connexion est établie avec la Featherwing RFM69
LED.value = True
print ("connexion etablie...")
print("Pour verification - Frequence: {0}MHz".format(rfm69.frequency_mhz))

# ---------------------------------------
# -------  BOUCLE PRINCIPALE  -----------
# ---------------------------------------
while True:
    # Test du bouton X
    if carte_joywing.button_x:
        print("Bouton X")
        # Envoi de la commande "Avant"
        rfm69.send(bytes("Avant\r\n", "utf-8"))
    # Test du bouton A
    elif carte_joywing.button_a:
        print("Bouton A")
        # Envoi de la commande "Droite"
        rfm69.send(bytes("Droite\r\n", "utf-8"))
    # Test du bouton Y
    elif carte_joywing.button_y:
        print("Bouton Y")
        # Envoi de la commande "Gauche"
        rfm69.send(bytes("Gauche\r\n", "utf-8"))
    # Test du bouton B
    elif carte_joywing.button_b:
        print("Bouton B")
        # Envoi de la commande "Arriere"
        rfm69.send(bytes("Arriere\r\n", "utf-8"))
    else :
        # Envoi de la commande "Stop"
        rfm69.send(bytes("Stop\r\n", "utf-8"))
    sleep(0.05)