"""7-8-2 : mini-clavier Macro"""
# importation des modules natifs utiles
from time import *
from board import *
from displayio import *
from terminalio import *
from digitalio import *
# importation de modules supplémentaires
from adafruit_debouncer import *
from adafruit_display_text import label
from adafruit_displayio_ssd1306 import *
import usb_hid
from adafruit_hid.keyboard import Keyboard
from adafruit_hid.keycode import Keycode

# Instanciation des boutons
Bouton_A = DigitalInOut(D9)
Bouton_A.direction = Direction.INPUT
Bouton_A.pull = Pull.UP
Bouton_B = DigitalInOut(D6)
Bouton_B.direction = Direction.INPUT
Bouton_B.pull = Pull.UP
Bouton_C = DigitalInOut(D5)
Bouton_C.direction = Direction.INPUT
Bouton_C.pull = Pull.UP

# Ajout de l'anti-rebond
Bouton_A_avec_antirebond = Debouncer(Bouton_A)
Bouton_B_avec_antirebond = Debouncer(Bouton_B)
Bouton_C_avec_antirebond = Debouncer(Bouton_C)

# Libère toute ressource déjà utilisée par displayio
displayio.release_displays()
# Instanciation du bus de communication I2C sur le module Feather
bus_i2c = I2C()
# Instanciation de l'écran OLED SSD1306 (n'utilise pas displayio)
ecran_bus = I2CDisplay(bus_i2c, device_address=0x3C)
affichage = SSD1306(ecran_bus, width=128, height=32)
# Instanciation du clavier
clavier = Keyboard(usb_hid.devices)

# Ecran de démarrage
groupe_splash = Group(max_size=1)
fichier = open("/images/Titre.bmp", "rb")
image = OnDiskBitmap(fichier)
tuile_titre = TileGrid(image, pixel_shader=ColorConverter())
groupe_splash.append(tuile_titre)
affichage.show(groupe_splash)
affichage.refresh()
fichier.close()
sleep(3)

# Mise en place des différents groupes affichables
groupe_principal = Group(max_size = 4)
groupe_attente = Group(max_size= 1, scale =2)
groupe_copier = Group(max_size= 3)
groupe_coller = Group(max_size= 3)
groupe_couper = Group(max_size= 3)
groupe_principal.append(groupe_attente)
index_groupe_attente = groupe_principal.index(groupe_attente)
groupe_principal.append(groupe_copier)
index_groupe_copier = groupe_principal.index(groupe_copier)
groupe_principal.append(groupe_coller)
index_groupe_coller = groupe_principal.index(groupe_coller)
groupe_principal.append(groupe_couper)
index_groupe_couper = groupe_principal.index(groupe_couper)
affichage.show(groupe_principal)

# Description des objets graphiques associés au groupe 'attente'
text_attente = label.Label(FONT, text="attente", color=0xFFFF00, x=12, y=8)
groupe_attente.append(text_attente)
# Description des objets graphiques associés au groupe 'copier'
text_copier1 = label.Label(FONT, text="WIN+C", color=0xFFFF00, x=48, y=8)
groupe_copier.append(text_copier1)
text_copier2 = label.Label(FONT, text="copier", color=0xFFFF00, x=48, y=23)
groupe_copier.append(text_copier2)
fichier1 = open("/images/Copier.bmp", "rb")
image1 = OnDiskBitmap(fichier1)
tuile_copier = TileGrid(image1, pixel_shader=ColorConverter())
groupe_copier.append(tuile_copier)
fichier.close()
# Description des objets graphiques associés au groupe 'coller'
text_coller1 = label.Label(FONT, text="WIN+V", color=0xFFFF00, x=48, y=8)
groupe_coller.append(text_coller1)
text_coller2 = label.Label(FONT, text="coller", color=0xFFFF00, x=48, y=23)
groupe_coller.append(text_coller2)
fichier2 = open("/images/Coller.bmp", "rb")
image2 = OnDiskBitmap(fichier2)
tuile_coller = TileGrid(image2, pixel_shader=ColorConverter())
groupe_coller.append(tuile_coller)
fichier.close()
# Description des objets graphiques associés au groupe 'couper'
text_couper1 = label.Label(FONT, text="WIN+X", color=0xFFFF00, x=48, y=8)
groupe_couper.append(text_couper1)
text_couper2 = label.Label(FONT, text="couper", color=0xFFFF00, x=48, y=23)
groupe_couper.append(text_couper2)
fichier3 = open("/images/Couper.bmp", "rb")
image3 = OnDiskBitmap(fichier3)
tuile_couper = TileGrid(image3, pixel_shader=ColorConverter())
groupe_couper.append(tuile_couper)
fichier.close()

# Fonction pour l'affichage de l'écran d'attente
def Attente():
    global groupe_principal, affichage
    global index_groupe_copier,index_groupe_coller,index_groupe_couper
    global index_groupe_attente
    # Cache les écrans correspondants aux macros et affiche l'écran d'attente
    groupe_principal[index_groupe_copier].hidden = True
    groupe_principal[index_groupe_coller].hidden = True
    groupe_principal[index_groupe_couper].hidden = True
    groupe_principal[index_groupe_attente].hidden = False
    affichage.refresh()

# Fonction pour l'affichage de l'écran correspondant à la touche macro appuyée
def Affichage_icone(nom):
    global groupe_principal, affichage
    global index_groupe_copier,index_groupe_coller,index_groupe_couper
    global index_groupe_attente
    # Cache l'écran 'attente'
    groupe_principal[index_groupe_attente].hidden = True
    # Affiche l'écran correspondant à l'action passée en paramètre
    if nom == "Copier" :
        groupe_principal[index_groupe_copier].hidden = False
        groupe_principal[index_groupe_coller].hidden = True
        groupe_principal[index_groupe_couper].hidden = True
    elif nom == "Coller" :
        groupe_principal[index_groupe_copier].hidden = True
        groupe_principal[index_groupe_coller].hidden = False
        groupe_principal[index_groupe_couper].hidden = True
    elif nom == "Couper" :
        groupe_principal[index_groupe_copier].hidden = True
        groupe_principal[index_groupe_coller].hidden = True
        groupe_principal[index_groupe_couper].hidden = False
    affichage.refresh()
    sleep(1)

# Affichage de l'écran d'attente en attendant un appui sur une touche
Attente()

# ---------------------------------------
# -------  BOUCLE PRINCIPALE  -----------
# ---------------------------------------
while True:
    # Mise à jour de la surveillance des boutons
    Bouton_A_avec_antirebond.update()
    Bouton_B_avec_antirebond.update()
    Bouton_C_avec_antirebond.update()
    # Test des différents boutons (front descendant) :
    if Bouton_A_avec_antirebond.fell :
        print("copier")
        # Envoi de la commande clavier 'CTRL+C'
        clavier.send(Keycode.CONTROL, Keycode.C)
        # Mise à jour de l'affichage
        Affichage_icone("Copier")
        Attente()
    if Bouton_B_avec_antirebond.fell :
        print("coller")
        # Envoi de la commande clavier 'CTRL+V'
        clavier.send(Keycode.CONTROL, Keycode.V)
        # Mise à jour de l'affichage
        Affichage_icone("Coller")
        Attente()
    if Bouton_C_avec_antirebond.fell :
        print("couper")
        # Envoi de la commande clavier 'CTRL+X'
        clavier.send(Keycode.CONTROL, Keycode.X)
        # Mise à jour de l'affichage
        Affichage_icone("Couper")
        Attente()
