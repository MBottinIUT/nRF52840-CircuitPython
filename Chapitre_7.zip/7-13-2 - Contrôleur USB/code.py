"""7-13-2 : contrôleur de jeu USB"""
# Importation des modules natifs utiles
from time import *
# importation de modules supplémentaires
import usb_hid
from adafruit_featherwing import joy_featherwing
from adafruit_hid.gamepad import Gamepad

# instanciation de la carte d'extension JoyWing
carte_joywing = joy_featherwing.JoyFeatherWing()

# Instanciation de l'émulateur USB de contrôleur de jeu
controleur = Gamepad(usb_hid.devices)

# Initialisation du seuil pour le joytsick
SEUIL = 60

# ---------------------------------------
# -------  BOUCLE PRINCIPALE  -----------
# ---------------------------------------
while True:
    # Récupération des informations liées au joystick analogique
    joystick_y, joystick_x = carte_joywing.joystick
    # Inversion de l'axe y
    joysticky = - joystick_y
    if (joystick_x > SEUIL) :
        controleur.press_buttons(1)
    else :
        controleur.release_buttons(1)
    if (joystick_x < -SEUIL) :
        controleur.press_buttons(2)
    else :
        controleur.release_buttons(2)
    if (joystick_y > SEUIL) :
        controleur.press_buttons(3)
    else :
        controleur.release_buttons(3)
    if (joystick_y < -SEUIL) :
        controleur.press_buttons(4)
    else :
        controleur.release_buttons(4)
    # Test du bouton A
    if carte_joywing.button_a:
        print("Bouton A")
        controleur.press_buttons(5)
    else :
        controleur.release_buttons(5)
    # Test du bouton B
    if carte_joywing.button_b:
        print("Bouton B")
        controleur.press_buttons(6)
    else :
        controleur.release_buttons(6)
    # Test du bouton X
    if carte_joywing.button_x:
        print("Bouton X")
        controleur.press_buttons(7)
    else :
        controleur.release_buttons(7)
    # Test du bouton Y
    if carte_joywing.button_y:
        print("Bouton Y")
        controleur.press_buttons(8)
    else :
        controleur.release_buttons(8)
    # Test du bouton SELECT
    if carte_joywing.button_select:
        print("Bouton SELECT")
        controleur.press_buttons(9)
    else :
        controleur.release_buttons(9)
    sleep(0.01)
