""" programme 7-11-3 : Horloge"""
# Importation des modules natifs utiles
from time import *
from board import *
from random import *
from displayio import *
from terminalio import *
from framebufferio import *
from rgbmatrix import *
from adafruit_display_text import label
from adafruit_display_shapes.circle import Circle
from adafruit_display_shapes.rect import Rect

# Libère toute ressource déjà utilisée par displayio
release_displays()

# Instanciation de la matrice 32x32
matrice = RGBMatrix(width=32, height=32, bit_depth=3, rgb_pins=[D6, SDA, D9, D11, D10, D12],
                addr_pins=[A5, A4, A3, A2], clock_pin=D2, latch_pin=RX, output_enable_pin=TX)
# Instanciation de l'affichage
affichage = FramebufferDisplay(matrice, auto_refresh=True)

# Réglage de l'heure dans le code
heures = 12
minutes = 26
secondes = 1

# Liste des coordonnées des 60 rectangles représentant les secondes
coord_rect = [(0,0),(2,0),(4,0),(6,0),(8,0),(10,0),(12,0),(14,0),(16,0),(18,0),\
            (20,0),(22,0),(24,0),(26,0),(28,0),(30,0),(30,2),(30,4),(30,6),(30,8),\
            (30,10),(30,12),(30,14),(30,16),(30,18),(30,20),(30,22),(30,24),(30,26),\
            (30,28),(30,30),(28,30),(26,30),(24,30),(22,30),(20,30),(18,30),(16,30),\
            (14,30),(12,30),(10,30),(8,30),(6,30),(4,30),(2,30),(0,30),(0,28),(0,26),\
            (0,24),(0,22),(0,20),(0,18),(0,16),(0,14),(0,12),(0,10),(0,8),(0,6),\
            (0,4),(0,2)]

# Création du groupe général contenant au maximum 64 couches/calques
groupe_horloge = Group(max_size=64)

# Mise en place de l'affichage de l'heure
# zone de texte pour l'affichage des heures
texte_heure = label.Label(terminalio.FONT, text=str(heures), color=0xFFFFFF)
texte_heure.x = 10
texte_heure.y = 8
groupe_horloge.append(texte_heure)
# Ligne de séparation entre les heures et les minutes
separation = Rect(4, 15, 24, 2, fill=0xFFFFFF)
groupe_horloge.append(separation)
# zone de texte pour l'affichage des minutes
texte_minute = label.Label(terminalio.FONT, text=str(minutes), color=0xFFFFFF)
texte_minute.x = 10
texte_minute.y = 22
groupe_horloge.append(texte_minute)

# ---------------------------------------
# -------  BOUCLE PRINCIPALE  -----------
# ---------------------------------------
while True :
    # génération des rectangles qui représentent les secondes qui s'écoulent
    for i in range (secondes) :
        rect = Rect(coord_rect[i][0], coord_rect[i][1], 2, 2, fill=0xFF0000)
        groupe_horloge.append(rect)
    # Mise à jour de l'affichage des heures et des minutes
    texte_heure.text = str(heures)
    texte_minute.text = str(minutes)
    # Rafraîchissement de l'affichage
    affichage.show(groupe_horloge)
    affichage.refresh()
    # Pause d'une seconde
    sleep(1.0)
    # Mise à jour des valeurs des heures, minutes et secondes
    secondes = secondes +1
    if secondes == 61 :
        secondes = 1
        minutes = minutes +1
        if minutes == 60 :
            minutes = 0
            heures = heures +1
            if heures == 23 :
                heures = 0
    # effacement de tous les rectangles qui représentent les secondes
    for i in range(len(groupe_horloge)-3) :
        groupe_horloge.pop(3)