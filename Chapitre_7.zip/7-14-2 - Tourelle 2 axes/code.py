"""7-14-2 : commande de tourelle"""
# Importation des modules natifs utiles
from time import *
# importation de modules supplémentaires
from adafruit_featherwing import joy_featherwing
from adafruit_servokit import ServoKit
from simpleio import *

# instanciation de la carte d'extension JoyWing
carte_joywing = joy_featherwing.JoyFeatherWing()

# instanciation de la carte d'extension servo avec 8 canaux
carte_servo = ServoKit(channels=8)

# Réglage des limites pour le servomoteur de la base
#carte_servo.servo[0].set_pulse_width_range(591, 2253)
carte_servo.servo[0].set_pulse_width_range(1050, 1650)
# Réglage des limites pour le servomoteur de la plateforme
#carte_servo.servo[1].set_pulse_width_range(756, 2382)
carte_servo.servo[1].set_pulse_width_range(1200, 2100)

# ---------------------------------------
# -------  BOUCLE PRINCIPALE  -----------
# ---------------------------------------
while True:
    # Récupération des informations liées au joystick analogique
    joystick_x, joystick_y = carte_joywing.joystick
    # Inversion des axes x et y pour des facilités de prise en main
    joystick_y = - joystick_y
    joystick_x = - joystick_x
    # Conversion des valeurs des axes du joystick en angle pour les servos
    angle_plateforme = map_range(joystick_x, -128, 128, 0, 180)
    angle_base = map_range(joystick_y, -128, 128, 0, 180)
    # Commande en angle des deux servos
    carte_servo.servo[0].angle = angle_base
    carte_servo.servo[1].angle = angle_plateforme
    # Pause
    sleep(0.1)
