""" 7-6-5 : Badge évènement """
# importation des modules natives utiles
from time import *
from board import *
from displayio import *
# importation de modules supplémentaires
from adafruit_il0373 import *

# Déclaration des couleurs
ROUGE = 0xFF0000

# Libère toute ressource déjà utilisée par displayio
displayio.release_displays()

# Instanciation du bus de communication SPI sur le module Feather
bus_spi = SPI()
epd_cs = D9
epd_dc = D10
epd_reset = D5
epd_busy = D6

# Instanciation de l'écran e-Paper IL0373 (3 couleurs - 3ème couleur = ROUGE)
bus_affichage = FourWire(bus_spi, command=epd_dc, chip_select=epd_cs,
                                 reset=epd_reset, baudrate=1000000)
sleep(1)
ecran = IL0373(bus_affichage, width=212, height=104, rotation=90,
                    busy_pin=epd_busy, highlight_color=ROUGE)

# Ajout de la première image
# Création du groupe général de la page 1
groupe1 = Group(max_size=1)
# Ouverture du fichier
fichier1 = open("/images/Badge_page_1.bmp", "rb")
# Extraction des données uniquement liées à l'image depuis le fichier du disque
page1 = OnDiskBitmap(fichier1)
# Création d'une tuile image basée sur le bitmap 'page1'
tuile_image1 = TileGrid(page1, pixel_shader=ColorConverter(),x=0,y=0)
# Ajoute cette tuile image au groupe 1
groupe1.append(tuile_image1)

# Ajout de la seconde image
# Création du groupe général de la page 2
groupe2 = Group(max_size=1)
# Ouverture du fichier
fichier2 = open("/images/Badge_page_2.bmp", "rb")
# Extraction des données uniquement liées à l'image depuis le fichier du disque
page2 = OnDiskBitmap(fichier2)
# Création d'une tuile image basée sur le bitmap 'page2'
tuile_image2 = TileGrid(page2, pixel_shader=ColorConverter(),x=0,y=0)
# Ajoute cette tuile image au groupe 2
groupe2.append(tuile_image2)

# Boucle infinie
while True:
    # Affichage de la page 1
    print ("page 1")
    ecran.show(groupe1)
    ecran.refresh()
    sleep(180)
    # Affichage de la page 1
    print ("page 2")
    ecran.show(groupe2)
    ecran.refresh()
    sleep(180)
