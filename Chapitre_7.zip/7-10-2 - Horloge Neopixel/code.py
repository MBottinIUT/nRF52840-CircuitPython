""" programme 7-10-2 : Horloge Neopixel"""
# Importation des modules natifs utiles
from time import *
from board import *
from digitalio import *
# importation de modules supplémentaires
from adafruit_featherwing import rtc_featherwing
from neopixel import *

# Instanciation de l'horloge temps réel RTC (ici DS3231)
rtc = rtc_featherwing.RTCFeatherWing()

# Instanciation de la broche de validation générale de la Featherwing Prop Maker
enable = DigitalInOut(D10)
enable.direction = Direction.OUTPUT
enable.value = True

# Instanciation du disque Neopixel à 60 LED
led = NeoPixel(D5, 60, brightness=1.0)

# Réglage manuel de l'heure dans le code
if False:  # True permet de régler l'heure, False de conserver l'heure de la RTC
    rtc.set_time(15, 13, 25)  # (H,M,S)
    #print(rtc.now)

# Définition des couleurs utilisées pour les LED de l'horloge
COULEUR_SECONDE = 0xfff9f9
COULEUR_MINUTE = 0xfeed00
COULEUR_HEURE = 0xf5110c
ETEINTE = 0x000000

# Lecture de l'heure depuis la RTC et affichage au démarrage
now = rtc.now
last_heure = int(((now.hour %12)*5) + (now.minute //12))
last_minute = now.minute
last_seconde = now.second
led[59-last_seconde] = COULEUR_SECONDE
led[59-last_minute] = COULEUR_MINUTE
led[59-last_heure] = COULEUR_HEURE

# ---------------------------------------
# -------  BOUCLE PRINCIPALE  -----------
# ---------------------------------------
while True:
    # Lecture de l'heure actuelle depuis la RTC
    now = rtc.now
    # Calcul de la LED correspondant à l'heure
    heure_actuelle = int(((now.hour %12)*5) + (now.minute //12))
    # Récupération des minutes
    minute_actuelle = now.minute
    # Récupération des secondes
    seconde_actuelle = now.second
    # Affichage dans la console (debug)
    print("Il est {}:{:02}:{:02}".format(now.hour, now.minute,now.second))
    # MAJ de la LED des secondes si elle ne se superpose pas à celle des minutes
    # ou des heures
    if (seconde_actuelle != last_seconde) :
        led[59-last_seconde] = ETEINTE
    if (seconde_actuelle != last_minute) and (seconde_actuelle != last_heure) :
        led[59-seconde_actuelle] = COULEUR_SECONDE
    # MAJ de la LED des minutes si elle ne se superpose pas à celle des heures
    if (minute_actuelle != last_minute) :
        led[59-last_minute] = ETEINTE
    if (minute_actuelle != last_heure) :
        led[59-minute_actuelle] = COULEUR_MINUTE
    # MAJ de la LED des heures
    if (heure_actuelle != last_heure):
        led[59-last_heure] = ETEINTE
    led[59-heure_actuelle] = COULEUR_HEURE
    # Enregistrement de l'heure actuelle pour la prochaine itération
    last_heure = heure_actuelle
    last_minute = minute_actuelle
    last_seconde = seconde_actuelle
    # Attente de 100 ms
    sleep(0.1)
