""" 7-7-2 : Test de la zone tactile resistive """
# importation des modules natifs utiles
from time import *
from board import *
from digitalio import *
from displayio import *
# importation de modules supplémentaires
from adafruit_ili9341 import *
from adafruit_stmpe610 import *

# Libère toute ressource déjà utilisée par displayio
release_displays()
# Instanciation du bus de communication SPI sur le module Feather
bus_spi = SPI()
tft_cs = D9
tft_dc = D10
# Instanciation de l'écran LCD TFT ILI9341
bus_affichage = FourWire(SPI(), command=tft_dc, chip_select=tft_cs)
ecran = ILI9341(bus_affichage, width=320, height=240)
# Instanciation de la dalle résistive STMPE610
touch_cs = DigitalInOut(D6)
zone_tactile = Adafruit_STMPE610_SPI(bus_spi, touch_cs)

dernier_temps =0

# BOUCLE INFINIE
while True:
    # Teste si un appui sur l'écran a été effectué
    if not zone_tactile.buffer_empty:
        # enregistrement du temps
        temps = monotonic()
        #print (temps)
        # Lecture de la première donnée qui correspond au premier contact sur l'écran
        (X,Y,P) = zone_tactile.read_data()
        #print("x:{} / y:{} / pression:{}".format(X,Y,P))
        # Tant que le contact est maintenu, le buffer s'est rempli
        # On le vide donc ici pour le point de contact suivant
        while not zone_tactile.buffer_empty :
            (tempx,tempy,tempp) = zone_tactile.read_data()
        # Si il s'est écoulé plus de une seconde depuis le dernier appui
        if (temps - dernier_temps > 1.0) :
            dernier_temps = temps
            # selon la coordonnée Y, on détermine l'action
            if (Y < 1000) :
                print("image precedente...")
            elif (Y > 3000) :
                print("image suivante...")
