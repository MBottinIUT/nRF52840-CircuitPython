"""7-9-4 : lampe d'ambiance"""
# importation des modules natifs utiles
from pulseio import *
from board import *
from digitalio import *
from time import *
from busio import *
from random import *
# importation de modules supplémentaires
from adafruit_lis3dh import *
from adafruit_fancyled.adafruit_fancyled import *

# Instanciation de la broche de validation générale de la Featherwing Prop Maker
enable = DigitalInOut(D10)
enable.direction = Direction.OUTPUT
enable.value = True

# Création des 3 commandes PWM pour une LED RGB 3W
rouge = PWMOut(D11, duty_cycle=0, frequency=20000)
vert = PWMOut(D12, duty_cycle=0, frequency=20000)
bleu = PWMOut(D13, duty_cycle=0, frequency=20000)

# Instanciation du bus I2C et de l'accéléromètre LIS3DH de la Featherwing
i2c = I2C(SCL, SDA)
int1 = DigitalInOut(D6)
accelerometre = LIS3DH_I2C(i2c, int1=int1)
accelerometre.set_tap(1, 100)

# ---------------------------------------
# -------  BOUCLE PRINCIPALE  -----------
# ---------------------------------------
while True:
    # Si l'accéléromètre a subi une "frappe"
    if accelerometre.tapped:
        print("Touche !")
        # Génération d'une teinte aléatoire
        teinte = random()
        # Génération de la couleur correspondante à la teinte
        couleur_HSV = CHSV(teinte, 1.0, 1.0)
        # Conversion de HSV vers RGB
        couleur_RGB = couleur_HSV.pack()
        # Conversion de la couleur du format hex en tuple (R,G,B)
        couleur_RGB = unpack(couleur_RGB)
        # Changement des valeurs de rapport cyclique des 3 PWM R,V,B
        rouge.duty_cycle = int(couleur_RGB[0] * 65535)
        vert.duty_cycle = int(couleur_RGB[1] * 65535)
        bleu.duty_cycle = int(couleur_RGB[2] * 65535)
