""" programme 7-9-2 : voltmètre parlant"""
# Importation des modules natifs utiles
from time import *
from board import *
from digitalio import *
from analogio import *
from audiocore import WaveFile
from audiopwmio import PWMAudioOut as AudioOut
# importation de modules supplémentaires
from adafruit_debouncer import *

# Instanciation de la broche de validation générale de la Featherwing Prop Maker
enable = DigitalInOut(D10)
enable.direction = Direction.OUTPUT
enable.value = True

# Instanciation d'une broche analogique pour la mesure de tension
voltmetre = AnalogIn(A1)

# Instanciation du bouton
Bouton = DigitalInOut(D2)
Bouton.direction = Direction.INPUT
Bouton.pull = Pull.UP
# Ajout de l'anti-rebond
Bouton_avec_antirebond = Debouncer(Bouton)

# Fonction de calcul de la tension sur la broche analogique spécifiée
def mesure_tension(broche):
    return round(((broche.value * 3.3) / 65536),1)

# Fonction permettant de lire un fichier audio wave avec une broche PWM
def lecture_audio(nom_fichier):
    # Ouverture du fichier audio fourni en paramètre
    fichier_wave = open("sounds/"+nom_fichier, "rb")
    # Lecture du fichier
    with WaveFile(fichier_wave) as wave:
        with AudioOut(A0) as audio:
            audio.play(wave)
            # Attente que la lecture audio du fichier soit terminée
            while audio.playing:
                pass

# fichiers audio mono wave 16 bits 16kHz pour la lecture de la tension
unites = ["zero.wav", "un.wav", "deux.wav", "trois.wav"]
dixiemes = ["virgule_zero.wav","virgule_un.wav","virgule_deux.wav","virgule_trois.wav",\
            "virgule_quatre.wav","virgule_cinq.wav","virgule_six.wav","virgule_sept.wav",\
            "virgule_huit.wav","virgule_neuf.wav"]

# ---------------------------------------
# -------  BOUCLE PRINCIPALE  -----------
# ---------------------------------------
while True :
    # Mise à jour de la surveillance du bouton
    Bouton_avec_antirebond.update()
    # Teste si un front descendant s'est produit, c'est-à-dire que l'on a appuyé
    # sur le bouton
    if Bouton_avec_antirebond.fell :
        tension = mesure_tension(voltmetre)
        # Décomposition de la tension pour récupérer le chiffre des unités et le
        # chiffre des dizièmes
        unite_tension = int(tension)
        unite_dixieme = int((tension - unite_tension)*10)
        # Lecture audio des trois fichiers audio correspondant à la tension
        lecture_audio(unites[unite_tension])
        lecture_audio(dixiemes[unite_dixieme])
        lecture_audio("volt.wav")
        sleep(0.5)

