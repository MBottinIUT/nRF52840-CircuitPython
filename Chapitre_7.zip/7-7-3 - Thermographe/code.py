""" 7-7-3 : thermographe """
# importation des modules natifs utiles
from time import *
from board import *
from digitalio import *
from displayio import *
from terminalio import *
from storage import *
# importation de modules supplémentaires
from adafruit_sdcard import *
from adafruit_ili9341 import *
from adafruit_display_text import label
from adafruit_display_shapes.line import Line
from adafruit_display_shapes.rect import Rect

# Déclaration des couleurs utiles
NOIR = 0x000000
BLANC = 0xFFFFFF
VERT_CLAIR = 0x0CCF40
GRIS_FONCE = 0x78756D

# Libère toute ressource déjà utilisée par displayio
release_displays()
# Instanciation du bus de communication SPI sur le module Feather
bus_spi = SPI()
tft_cs = D9
tft_dc = D10
# Instanciation de l'écran LCD TFT ILI9341
bus_affichage = FourWire(SPI(), command=tft_dc, chip_select=tft_cs)
ecran = ILI9341(bus_affichage, width=320, height=240)

# Instanciation de la carte SD intégrée à l'écran
sd_cs = DigitalInOut(D5)
sdcard = SDCard(SPI(), sd_cs)
# Montage de la carte SD avec le chemin "/sd/"
vfs = VfsFat(sdcard)
mount(vfs, "/sd")

# Création d'une liste de températures vide
temperatures=[]

# Lecture du fichier tableur contenant les températures
with open("/sd/temp.csv", "r") as fichier:
    print("Lecture du fichier...")
    ligne = "ABC"
    # Boucle de lecture tant que le fichier comporte des lignes non vides
    while ligne != '':
        # Lecture d'une ligne (format --> 'HH:MM:SS;xx.x\n')
        ligne = fichier.readline()
        # Extraction de la température en valeur entière
        temperature_lue = ligne[-5:]
        temperature_lue = temperature_lue[:2]
        # Ajout de la température extraite à la liste 'temperatures'
        if temperature_lue != '' :
            temperatures.append(int(temperature_lue))

# Création du groupe général pour l'écran
groupe = Group(max_size=5 + 2*len(temperatures))

# Création d'un bitmap pour le fond de la résolution de l'écran avec 1 bit/pixel
fond = Bitmap(320, 240, 1)
# Création d'une palette contenant les couleurs utiles pour le graphique
palette_fond = Palette(1)
# Fixe la couleur de la palette
palette_fond[0] = GRIS_FONCE
# Création d'une tuile remplie par le bitmap de fond et de couleur 'palette'
tuile_fond = TileGrid(fond, pixel_shader=palette_fond)
# Ajoute cette tuile au groupe général
groupe.append(tuile_fond)

# Affichages des axes avec leurs labels
temperature_min = min(temperatures)-1
temperature_max = max(temperatures)+1
nombre_graduations_temp = (temperature_max - temperature_min)
pas_temperature = 200 // nombre_graduations_temp
nombre_graduations_temps = len(temperatures)
pas_temps = 300 // nombre_graduations_temps
groupe.append(Line(10, 20, 10, 220, BLANC))
groupe.append(Line(10, 220, 310, 220, BLANC))
axe_Y = label.Label(FONT, text="Temperature", x=0, y=5,color=BLANC)
groupe.append(axe_Y)
axe_X = label.Label(FONT, text="Temps", x=280, y=230,color=BLANC)
groupe.append(axe_X)

# Affichage des températures sous forme de rectangles
index = 0
for temp_i in temperatures :
    # Calcul des coordonnées X,Y du coin gauche de chaque rectangle
    X1 = 11 + (index*pas_temps)
    Y1 = 219 - ((temp_i - temperature_min)*pas_temperature)
    # Calcul de la largeur et de la hauteur de chaque rectangle
    largeur = int(pas_temps / 1.5)
    hauteur = (temp_i - temperature_min)*pas_temperature
    # Affichage du rectangle
    groupe.append(Rect(X1, Y1, largeur, hauteur, fill=VERT_CLAIR, outline=NOIR, stroke=1))
    # Affichage de la valeur de la température au sommet du rectangle
    groupe.append(label.Label(FONT, text=str(temp_i), x=X1, y=Y1-10,color=BLANC))
    index = index +1

# Affiche le groupe général sur l'écran
ecran.show(groupe)

# Rafraîchissement complet de l'écran (tous les groupes seront rafraîchis)
# NOTE: 1 rafraichissement max / 180 secondes
ecran.refresh()

# BOUCLE INFINIE
while True:
    pass
