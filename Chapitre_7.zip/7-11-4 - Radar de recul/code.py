""" Programme 7-11-3 : Radar de recul """
# Importation des modules natifs utiles
from time import *
from board import *
from analogio import *
from pulseio import *
from displayio import *
from framebufferio import *
from rgbmatrix import *
# importation de modules supplémentaires
from simpleio import *

# Libère toute ressource déjà utilisée par displayio
release_displays()

# Instanciation de la matrice 32x32
matrice = RGBMatrix(width=32, height=32, bit_depth=3, rgb_pins=[D6, SDA, D9, D11, D10, D12],
                addr_pins=[A5, A4, A3, A2], clock_pin=D2, latch_pin=RX, output_enable_pin=TX)
# Instanciation de l'affichage
affichage = FramebufferDisplay(matrice, auto_refresh=True)

# Instanciation d'une broche analogique
capteur = AnalogIn(A1)

# Fonction de calcul de la tension sur la broche analogique
def mesure_tension(broche) :
    return (broche.value *3.3)/65536

# Fonction de détermination de la distance de l'obstacle
def calcul_distance(tension) :
    return ((13 - (0.42*tension))/tension)

# Liste des images à associer à la valeur de la distance de l'obstacle
images = ["Radar0000", "Radar0001", "Radar0002", "Radar0003", "Radar0004", \
        "Radar0005", "Radar0006", "Radar0007", "Radar0008", "Radar0009", \
        "Radar0010", "Radar0011", "Radar0012", "Radar0013", "Radar0014", \
        "Radar0015", "Radar0016"]

# Mise en place du groupe principal de l'affichage
groupe_principal = Group(max_size=17)
# Liste des numéros des groupes qui seront insérés dans le groupe principal
index_groupes =[0] * 17

# Mise en place de l'affichage en intégrant les 17 sous-groupes au groupe principal
for i in range(17) :
    # création d'un sous-groupe de taille 1
    groupe = Group(max_size=1)
    # lecture du fichier image et ajout de l'image au sous-groupe
    fichier = open("images/"+images[i]+".bmp", 'rb')
    bitmap = OnDiskBitmap(fichier)
    tuile = TileGrid(bitmap, pixel_shader=ColorConverter())
    groupe.append(tuile)
    # ajout du sous-groupe au groupe principal
    groupe_principal.append(groupe)
    # récupération de la position du sous-groupe dans le groupe principal
    index_groupes[i] = groupe_principal.index(groupe)
    # cache le sous-groupe pour qu'il ne soit pas affiché au démarrage
    groupe_principal[index_groupes[i]].hidden = True

distance_old=0
# ---------------------------------------
# -------  BOUCLE PRINCIPALE  -----------
# ---------------------------------------
while True:
    # Mesure de la distance via la broche analogique du capteur
    distance = round(calcul_distance(mesure_tension(capteur)),1)
    # Limitation de la plage de mesure à la plage du capteur
    if (distance >= 30.0) :
        distance = 30.0
    if (distance <= 4.0) :
        distance = 4.0
    # Affichage de la distance dans la console
    print("Distance : {} cm(s)".format(distance))
    # détermination du numéro de l'image à afficher selon la distance mesurée
    distance = int(map_range(distance, 4, 30, 0, 16))
    # cache l'image correspondant à la mesure de distance précédente
    groupe_principal[index_groupes[distance_old]].hidden = True
    # Affichage de l'image correspondante à la distance
    groupe_principal[index_groupes[distance]].hidden = False
    # affichage du groupe principal et rafraîchissement de la matrice
    affichage.show(groupe_principal)
    affichage.refresh()
    # sauvegarde de la mesure de distance pour l'itération suivante
    distance_old = distance
    # Attente de 50ms
    sleep(0.05)